<?php
/*
Template Name: Home 02

Sidebar: false
*/
?>
<?php get_remix_header(); ?>

<div id="banner2">
  <div id="banner-in2">
         <div class="bsubcolum alignleft">
            <h2>Basic</h2>
                <ul class="pfeture">
                   <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.  </li>
                   <li>Praesent aliquam,  justo convallis luctus rutrum </li>
                   <li>Erat nulla fermentum diam, at nonummy quam  ante ac quam. </li>
            	</ul>
		</div><!-- bsubcolum #end  -->
        
        <div class="bsubcolum alignleft">
            <h2>Style</h2>
                <ul class="pfeture">
                   <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.  </li>
                   <li>Praesent aliquam,  justo convallis luctus rutrum </li>
                   <li>Erat nulla fermentum diam, at nonummy quam  ante ac quam. </li>
            	</ul>
		</div><!-- bsubcolum #end  -->
        
        <div class="bsubcolum alignleft">
            <h2>Pro</h2>
               <ul class="pfeture">
                   <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.  </li>
                   <li>Praesent aliquam,  justo convallis luctus rutrum </li>
                   <li>Erat nulla fermentum diam, at nonummy quam  ante ac quam. </li>
            	</ul>
		</div><!-- bsubcolum #end  -->
         
        
        
     
    
     
  </div>
</div>
<!--banner2 end -->



<div id="content-wrap">
      <div id="main">
        <?php /*remix_code_start*/ ?>
        	<div class="subcolumns alignleft">
            	<h3>Lorem ipsum dolor sit amet, consectetuer?</h3>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis.</p>
                
                <h3>Lorem ipsum dolor sit amet, consectetuer?</h3>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis.</p>
             </div><!--subcolum left #end -->
             
             
             <div class="subcolumns alignright">
            	<h3>Lorem ipsum dolor sit amet, consectetuer?</h3>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis.</p>
                
                <h3>Lorem ipsum dolor sit amet, consectetuer?</h3>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis.</p>
             </div><!--subcolum left #end -->
           
             
         
             
             
        <!--box start -->
        <div class="box">

 		<h4>All Plans Includes</h4>
        <ul class="pplans alignleft">
        	<li>Lorem ipsum dolor sit amet</li>
            <li>Consectetuer adipiscing elit. </li>
            <li>Praesent aliquam,  justo convallis </li>
            <li>nonummy quam  ante ac quam. </li>
        </ul>
        
         <ul class="pplans alignleft">
        	<li>Lorem ipsum dolor sit amet</li>
            <li>Consectetuer adipiscing elit. </li>
            <li>Praesent aliquam,  justo convallis </li>
            <li>nonummy quam  ante ac quam. </li>
        </ul>
        
         <ul class="pplans alignright">
        	<li>Lorem ipsum dolor sit amet</li>
            <li>Consectetuer adipiscing elit. </li>
            <li>Praesent aliquam,  justo convallis </li>
            <li>nonummy quam  ante ac quam. </li>
        </ul>
             
		</div>   <!--rounded corneer all plans #end -->
        
            
        
 </div><!--main #end -->
    
    <?php /*remix_code_end*/ ?>      
    
	
 <!--include footer-->
<?php get_footer(); ?>