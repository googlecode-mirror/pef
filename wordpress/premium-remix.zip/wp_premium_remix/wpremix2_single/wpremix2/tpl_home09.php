<?php
/*
Template Name: Home 09

Sidebar: false
*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
 
   <?php /*remix_code_start*/ ?>
 <div id="banner10">
  <h2> Your Site's Main Punchline comes here! Aenean tempus ignissim tortor. Ut condimentum. Mauris iaculis. </h2>
  <p> The secondary text explaining your site/business purpose like what and how it does etc. Below are the few options that you could use to highlight main features of your site/business. cursus quis, tortor. Nulla pede.</p>
  <p><a href="#"><strong>Read More &raquo;</strong></a></p>
</div> 
<!-- banner #end-->

			
       
       <!--content #start -->
      <div id="content">
      		 
             <h3>Services </h3>
             <p> consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in. </p>
   
   
   <ul class="option10">
      <li  class="i_feature1"><a href="#" class="bold">Lorem ipsum dolor site</a><br />Quisque dapibus fermentum quam. Donec semper tempus enim. </li>
      <li  class="i_feature2"><a href="#" class="bold">Lorem ipsum dolor site</a><br />Quisque dapibus fermentum quam. Donec semper tempus enim.</li>
      <li  class="i_feature3"><a href="#" class="bold" >Lorem ipsum dolor site</a><br />Quisque dapibus fermentum quam. Donec semper tempus enim.</li>
      <li  class="i_feature4"><a href="#" class="bold" >Lorem ipsum dolor site</a><br />Quisque dapibus fermentum quam. Donec semper tempus enim.</li>
    </ul>
   
      </div><!--content #end-->
    
      
      
      
      
       <div id="sidebar">
      	<h2>Latest News</h2>
      
        <ul>
        	<?php $recent = new WP_Query("cat=$wpr_exclude_news&showposts=5"); while($recent->have_posts()) : $recent->the_post();?>
            <li><a href="<?php the_permalink(); ?>">
            <span class="bold"> <?php the_title(); ?> </span> </a><br /> 
            <span class="date"> <?php the_time('j F, Y') ?>,  <?php the_time('g:i a') ?></span></li>
        <?php endwhile; ?>
        </ul>
       
      </div><!--sidebar #end-->
      
       <?php /*remix_code_end*/ ?>
    
<!--include footer-->
<?php get_footer(); ?>