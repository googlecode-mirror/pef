<?php
/*
Template Name: Inner Page 03


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
 
<!--content #start -->
      <div id="content">
      		   <h1 class="pagetitle"><?php the_title(); ?></h1>
                <h3 class="eventtitle">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</h3> 
               <img src="<?php bloginfo('template_url'); ?>/images/event1.jpg" alt=""  class="imgright"   />
                <p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor. </p>
	<p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor. </p>
    
    <p><strong>Venue :</strong> address here, lorem ipsum, 395002.</p>
	<p><strong>Time :</strong> 9:00 PM to 11:00 PM</p>
     
    <hr class="hr2 event_spacer" /> 
    
      <h3 class="eventtitle">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</h3> 
              
              <img src="<?php bloginfo('template_url'); ?>/images/event1.jpg" alt=""  class="imgleft"   />
                <p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor. </p>
	<p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor. </p>
    
    <p class="clear"><strong>Venue :</strong> address here, lorem ipsum, 395002.</p>
	<p><strong>Time :</strong> 9:00 PM to 11:00 PM</p>
    
     <hr class="hr2 event_spacer" /> 
             
</div><!--content #end-->
      
  <?php /*remix_code_end*/ ?>              
    
<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>
      
<!--include footer-->
<?php get_footer(); ?>