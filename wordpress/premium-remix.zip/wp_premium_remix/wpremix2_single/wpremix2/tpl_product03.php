<?php
/*
Template Name: Product 03


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
 
<!--content #start -->
<div id="content">
   <h1 class="pagetitle"><?php the_title(); ?></h1>
	<p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor. Nulla pede. Maecenas sed lorem. 
Cras condimentum feugiat sed, egestas vitae, lacus. Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum dictum est. dictum est. </p>
    
    
    <div class="productlist">
    	  <div class="product">
       	<h2>Product Name</h2>
            <div  class="acenter" ><img src="<?php bloginfo('template_url'); ?>/images/product_s2.png" alt=""  /></div>
           <p class="acenter"> Price : <strong>$ 98.95</strong></p>
        <ul class="feature">
            <li>Suspendisse elementum, justo at elementum consectetuer</li>
            <li>Tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. </li>
            <li>Cras condimentum dictum est. dictum est. lorem ipsum dolors</li>
        </ul>
         <p class="acenter"> <a href="#" class="more">More Info</a> <a href="#" class="more">Buy Now</a> </p>
       </div><!--product #end-->
        
        
        <div class="product">
        	<h2>Product Name</h2>
            <div  class="acenter" ><img src="<?php bloginfo('template_url'); ?>/images/product_s2.png" alt=""  /></div>
           <p class="acenter"> Price : <strong>$ 98.95</strong></p>
           <ul class="feature">
            <li>Suspendisse elementum, justo at elementum consectetuer</li>
            <li>Tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. </li>
            <li>Cras condimentum dictum est. dictum est. lorem ipsum dolors</li>
          </ul>
           <p class="acenter"> <a href="#" class="more" >More Info</a> <a href="#" class="more">Buy Now</a> </p>
        </div><!--product #end-->
        
        
        <div class="product">
        	<h2>Product Name</h2>
            <div  class="acenter" ><img src="<?php bloginfo('template_url'); ?>/images/product_s2.png" alt=""  /></div>
           <p class="acenter"> Price : <strong>$ 98.95</strong></p>
           <ul class="feature">
            <li>Suspendisse elementum, justo at elementum consectetuer</li>
            <li>Tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. </li>
            <li>Cras condimentum dictum est. dictum est. lorem ipsum dolors</li>
          </ul>
           <p class="acenter"> <a href="#" class="more" >More Info</a> <a href="#" class="more">Buy Now</a> </p>
        </div><!--product #end-->
        
     </div><!--productlist #end -->
</div><!--content #end-->
    <?php /*remix_code_end*/ ?>
      
<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>
      
<!--include footer-->
<?php get_footer(); ?>