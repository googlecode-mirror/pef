<?php
/*
Template Name: Inner Page 19


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
<!--content #start -->
<div id="content">

  <h1 class="pagetitle"><?php the_title(); ?></h1>
      	
         <h5>Nam blandit quam ut lacus. Dolor site amet aecenas urna purus, fermentum id, molestie in ?</h5>
         
         <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis.</p>
         
         <div class="pboxlist">
        <div class="iconbox"> <img src="<?php bloginfo('template_url'); ?>/images/i_globe2.png" alt=""  class="" /> </div>
         
         <div class="productbox">
         	 <h5>Nam blandit quam ut lacus. Dolor site amet aecenas urna purus, fermentum id, molestie in ?</h5>
          	<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis.</p>
          </div>
          
          </div><!-- pboxlist #end  -->
          
          
           <div class="pboxlist">
         <div class="iconbox"><img src="<?php bloginfo('template_url'); ?>/images/i_tools.png" alt=""  class="" /></div>
         
         <div class="productbox">
         	 <h5>Nam blandit quam ut lacus. Dolor site amet aecenas urna purus, fermentum id, molestie in ?</h5>
          	<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis.</p>
          </div>
          
          </div><!-- pboxlist #end  -->
          
          
            <div class="pboxlist">
         <div class="iconbox"><img src="<?php bloginfo('template_url'); ?>/images/i_service2.png" alt=""  class="" /></div>
         
         <div class="productbox">
         	 <h5>Nam blandit quam ut lacus. Dolor site amet aecenas urna purus, fermentum id, molestie in ?</h5>
          	<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis.</p>
          </div>
          
          </div><!-- pboxlist #end  -->
          
          
            <div class="pboxlist">
         <div class="iconbox"><img src="<?php bloginfo('template_url'); ?>/images/i_job.png" alt=""  class="" /></div>
         
         <div class="productbox">
         	 <h5>Nam blandit quam ut lacus. Dolor site amet aecenas urna purus, fermentum id, molestie in ?</h5>
          	<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis.</p>
          </div>
          
          </div><!-- pboxlist #end  -->
   		
   
      
   
      
       
   
   
    
</div><!--content #end-->
 <?php /*remix_code_end*/ ?>  

 
<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>
 
<!--include footer-->
<?php get_footer(); ?>
