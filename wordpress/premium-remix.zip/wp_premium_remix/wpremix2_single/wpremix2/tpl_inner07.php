<?php
/*
Template Name: Inner Page 07


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
 
<!--content #start -->
      <div id="content">
      		   <h1 class="pagetitle"><?php the_title(); ?></h1>
                <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis.</p>
                
                 
                 
                 
                 <h3>Plan Comparison</h3>
                 
                 <table width="100%" border="0" cellspacing="1" cellpadding="0">
                <tr class="thead">
                        <td>No.</td>
                        <td>Product Plans</td>
                        <td align="center">Basic</td>
                        <td align="center">Feature</td>
                        <td align="center"> Business</td>
                   </tr>
                      <tr class="row1">
                        <td align="center">1</td>
                        <td> Monthly Pricing Starting at</td>
                        <td align="center" class="red"><strong>$19.95</strong></td>
                        <td align="center" class="red" ><strong>$49.95</strong></td>
                        <td align="center" class="red"><strong>$99.95</strong></td>
                </tr>
                      <tr class="row2">
                       <td align="center">2</td>
                        <td>Hard Disk Storage</td>
                        <td align="center"><strong>250 MB</strong></td>
                        <td align="center"><strong>350 MB</strong></td>
                        <td align="center"><strong>500 MB</strong></td>
                   </tr>
                      <tr class="row1">
                       <td align="center">2</td>
                        <td>Monthly Transfer</td>
                        <td align="center"><strong>10 GB</strong></td>
                        <td align="center"><strong>Unlimited</strong></td>
                        <td align="center"><strong>Unlimited</strong></td>
                   </tr>
                      <tr class="row2">
                       <td align="center">3</td>
                        <td><a href="#">POP E-mail Accounts</a></td>
                        <td align="center">30</td>
                        <td align="center">50</td>
                        <td align="center">70</td>
                      </tr>
                      <tr class="row1">
                        <td align="center">4</td>
                        <td> <a href="#">Virus &amp; Spam Protection</a></td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_true.png" alt=""  /></td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_true.png" alt=""  /></td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_true.png" alt=""  /></td>
                      </tr>
                      <tr class="row2">
                       <td align="center">5</td>
                        <td> <a href="#">Database Storage </a></td>
                        <td align="center">-</td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_true.png" alt=""  /></td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_true.png" alt=""  /></td>
                   </tr>
                      <tr class="row1">
                       <td align="center">6</td>
                        <td><a href="#">WebTrends - Daily Site Statistics</a></td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_true.png" alt=""  /></td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_true.png" alt=""  /></td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_true.png" alt=""  /></td>
                   </tr>
                      <tr class="row1">
                        <td align="center"></td>
                        <td></td>
                        <td align="center"><a href="#" class="button">Buy Now</a></td>
                        <td align="center"><a href="#" class="button">Buy Now</a></td>
                        <td align="center"><a href="#" class="button">Buy Now</a></td>
                      </tr>
	    </table>
        
        <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis.</p>
                 <h3>Tabular Data</h3>
        
         <table width="100%" border="0" cellspacing="1" cellpadding="0">
                      <tr class="thead">
                        <td>No.</td>
                        <td>Title</td>
                        <td>Name</td>
                        <td>Address</td>
                        <td colspan="2"> Action</td>
                      </tr>
                      <tr class="row1">
                        <td align="center">1</td>
                        <td> Lorem ipsum dolor</td>
                        <td>Rajesh Joshi</td>
                        <td>address here - 395002</td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_edit.png" alt=""  /></td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_delete.png" alt=""  /></td>
                      </tr>
                      <tr class="row2">
                       <td align="center">2</td>
                        <td> Lorem ipsum dolor</td>
                        <td>Rajesh Joshi</td>
                        <td>address here - 395002</td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_edit.png" alt=""  /></td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_delete.png" alt=""  /></td>
                      </tr>
                      <tr class="row1">
                       <td align="center">2</td>
                        <td> Lorem ipsum dolor</td>
                        <td>Rajesh Joshi</td>
                        <td>address here - 395002</td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_edit.png" alt=""  /></td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_delete.png" alt=""  /></td>
                      </tr>
                      <tr class="row2">
                       <td align="center">3</td>
                        <td> Lorem ipsum dolor</td>
                        <td>Rajesh Joshi</td>
                        <td>address here - 395002</td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_edit.png" alt=""  /></td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_delete.png" alt=""  /></td>
                      </tr>
                      <tr class="row1">
                        <td align="center">4</td>
                        <td> Lorem ipsum dolor</td>
                        <td>Rajesh Joshi</td>
                        <td>address here - 395002</td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_edit.png" alt=""  /></td>
                        <td align="center"><img src="<?php bloginfo('template_url'); ?>/images/i_delete.png" alt=""  /></td>
                      </tr>
       			 </table>
                 

</div><!--content #end-->
      <?php /*remix_code_end*/ ?>

<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar6.php'); ?>
      
<!--include footer-->
<?php get_footer(); ?>