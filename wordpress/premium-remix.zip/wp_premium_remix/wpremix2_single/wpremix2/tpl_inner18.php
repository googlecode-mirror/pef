<?php
/*
Template Name: Inner Page 18


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
<!--content #start -->
<div id="content">

  <h1 class="pagetitle"><?php the_title(); ?></h1>
      
   
 <div class="magazine_left">  
 <img src="<?php bloginfo('template_url'); ?>/images/magazine1.png" alt=""    /> 
 
 
 	
    <!-- dyanamic testimonials-->  
		 <?php include (TEMPLATEPATH . "/includes/testimonials.php"); ?>
         <!--# end--> 
 
 </div>
      
<div class="magazine">
      <h3>Book: Empowering India</h3>
      
                  
      
      <p class="clear">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum Nam blandit quam ut lacus. Dolor site amet aecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus.</p>
      
       <img src="<?php bloginfo('template_url'); ?>/images/i_globe2.png" alt=""  class="alignleft"  />
       <div class="mcontent">
        <p class="clear">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, 
        justo convallis luctus rutrum Nam blandit quam ut lacus. </p>
        </div>
       
       <hr class="hr" /> 
       
        <img src="<?php bloginfo('template_url'); ?>/images/i_pc.png" alt=""  class="alignleft"  />
       <div class="mcontent">
        <p class="clear">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, 
        justo convallis luctus rutrum Nam blandit quam ut lacus. </p>
        </div>
       
       <hr class="hr" /> 
       
       
        <img src="<?php bloginfo('template_url'); ?>/images/i_job.png" alt=""  class="alignleft"  />
       <div class="mcontent">
        <p class="clear">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, 
        justo convallis luctus rutrum Nam blandit quam ut lacus. </p>
        </div>
       
       <hr class="hr" /> 
      
     
      
<div class="box">
      		  <p><strong>Note: Lorem ipsum dolor sit amet, consectetuer adipiscing elit. </strong></p>
              
               <p><strong>List Price : <s>$ 50.00 </s></strong></p>
     <p><strong>Price : $ 40.00 </strong></p>
     
    <a href="#" class="button alignleft" >Add to Cart</a>
       </div>
      
       
  </div><!--magazine #end -->
  
 	
   
    
</div><!--content #end-->

 <?php /*remix_code_end*/ ?>  
 
<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>
 
<!--include footer-->
<?php get_footer(); ?>
