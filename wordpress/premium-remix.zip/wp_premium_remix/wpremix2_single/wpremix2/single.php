<?php
global $options;
foreach ($options as $value) {
		global $$value['id'];
        if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
?> 
<?php
$post = $wp_query->post;
if ( in_category("$pt_home_gallery") ) 
{
	include(TEMPLATEPATH . '/single_gallery.php');
} 
else {
	include(TEMPLATEPATH . "/single_blog.php");
}
?>