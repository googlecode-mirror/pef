<?php
/*
Template Name: Inner Page 15


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
<!--content #start -->
<div id="content">

  <h1 class="pagetitle"><?php the_title(); ?></h1>
   <img src="<?php bloginfo('template_url'); ?>/images/w1.png" alt="" class="imgright"  />
  
  <p>Worem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis ligula. Phasellus tristique purus a augue condimentum adipiscing. Aenean sagittis. Etiam leo pede, rhoncus venenatis, tristique in, vulputate at, odio. Donec et ipsum et sapien vehicula nonummy. Suspendisse potenti. Fusce varius urna id quam. Sed neque mi, varius eget, tincidunt nec, suscipit id, libero. In eget purus. Vestibulum ut nisl. </p>
  
  
  <div class="subcolumns alignleft sub_spcaer">
  	<h3>Lorem ipsum dolor?</h3>
    <img src="<?php bloginfo('template_url'); ?>/images/f6.png" alt="" class="imgleft"  />
    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. </p>
<p>Nam blandit quam ut lacus. Quisque ornare risus quis ligula. Phasellus tristique purus a augue condimentum adipiscing. Aenean sagittis. Etiam leo pede, rhoncus venenatis, tristique in, vulputate at, odio. Donec et ipsum et sapien vehicula nonummy. Suspendisse potenti.  </p>
  </div><!--subcolumns left #end -->
  
  
  <div class="subcolumns alignright sub_spcaer">
     
    <div class="box">
			<h3>Events</h3>
            
            <div class="lnews">
            	<img src="<?php bloginfo('template_url'); ?>/images/f1.png" alt="" class="fimg"  />
                <p><strong>Lorem ipsum dolor sit amet</strong> <br />consectetuer adipiscing elit. Praesent aliquam, 
                justo convallis luctus rutr </p>
            </div><!--lnews bottom-->
            
            <div class="lnews">
            	<img src="<?php bloginfo('template_url'); ?>/images/f2.png" alt="" class="fimg"  />
                <p><strong>Lorem ipsum dolor sit amet</strong> <br />consectetuer adipiscing elit. Praesent aliquam, 
                justo convallis luctus rutr </p>
            </div><!--lnews bottom-->
            
            <div class="lnews">
            	<img src="<?php bloginfo('template_url'); ?>/images/f1.png" alt="" class="fimg"  />
                <p><strong>Lorem ipsum dolor sit amet</strong> <br />consectetuer adipiscing elit. Praesent aliquam, 
                justo convallis luctus rutr </p>
            </div><!--lnews bottom-->
            
      </div>
    
  </div><!--subcolumns left #end -->
  
  
  <h3 class="clear">Lorem ipsum dolor?</h3>
  <img src="<?php bloginfo('template_url'); ?>/images/p1.png" alt="" class="imgleft"  />
  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis ligula. Phasellus tristique purus a augue condimentum adipiscing.  </p>
  
  <p class="bold italic">&ldquo;  Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus. &rdquo;</p>
  
   
 
   
</div><!--content #end-->
 <?php /*remix_code_end*/ ?>  

 
<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>
 
<!--include footer-->
<?php get_footer(); ?>
