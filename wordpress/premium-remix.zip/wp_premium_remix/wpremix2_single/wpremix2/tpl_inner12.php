<?php
/*
Template Name: Inner Page 12

Sidebar: false
*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
<!--content #start -->
<div id="main">

  <h1 class="pagetitle"><?php the_title(); ?></h1>
  <div id="banner5">
   	<div class="b5content"> <h2>WP Remix</h2>  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam</p> </div>
  </div><!--banner5 #end-->
  
	<p class="highlight">  Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat 
nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in,
 commodo porttitor, felis. Nam blandit quam ut lacus. </p>
  
  
  <div class="columns3 alignleft">
  	<h3>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</h3>
    <p>Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis ligula.</p>
    
    <img src="<?php bloginfo('template_url'); ?>/images/w1.png" alt="" class="columns_img"  />
  </div><!--columns3 #end-->
  
  
  <div class="columns3 alignleft columns_spacer">
  	<h3>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</h3>
    <p>Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis ligula.</p>
    
    <img src="<?php bloginfo('template_url'); ?>/images/w2.png" alt="" class="columns_img"  />
  </div><!--columns3 #end-->
  
  
  <div class="columns3 alignright">
  	<h3>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</h3>
    <p>Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis ligula.</p>
    
    <img src="<?php bloginfo('template_url'); ?>/images/w1.png" alt="" class="columns_img"  />
  </div><!--columns3 #end-->
   
 </div><!--main #end-->
 <?php /*remix_code_end*/ ?>  

<!--include footer-->
<?php get_footer(); ?>
