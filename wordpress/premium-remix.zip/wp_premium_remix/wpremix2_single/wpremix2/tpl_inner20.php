<?php
/*
Template Name: Inner Page 20


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
<!--content #start -->
<div id="content">

  <h1 class="pagetitle"><?php the_title(); ?></h1>
  
   <p> Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor.</p>
      	
          
           <div class="main_columns">
                <div class="subcolumns alignleft">
                
                       	 <h3>Article Title Here</h3>
                         
                          <img src="<?php bloginfo('template_url'); ?>/images/article1.jpg" alt="" class="articleimg"  />
                         
                        <p> Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor.</p>
                        <ul>
                        <li>Quisque dapibus fermentum quam.</li>
                        <li>Donec semper tempus enim.</li>
                         </ul>
                         <p ><a href="#" class="more">Readmore </a></p>
                         
                         <hr class="hr2" />
                  </div><!--subcolumns #end-->
                  
                  
                     <div class="subcolumns alignright ">
                       	 <h3>Article Title Here</h3>
                         <img src="<?php bloginfo('template_url'); ?>/images/article2.jpg" alt="" class="articleimg"  />
                        <p> Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor.</p>
                        <ul>
                        <li>Quisque dapibus fermentum quam.</li>
                        <li>Donec semper tempus enim.</li>
                         </ul>
                         <p ><a href="#" class="more">Readmore </a></p>
                         
                         <hr class="hr2" />
                  </div><!--subcolumns #end-->
                    </div><!--main_columns #end-->
        
   		
   	<div class="main_columns">
                <div class="subcolumns alignleft">
                       	 <h3>Article Title Here</h3>
                          <img src="<?php bloginfo('template_url'); ?>/images/article1.jpg" alt="" class="articleimg"  />
                        <p> Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor.</p>
                        <ul>
                        <li>Quisque dapibus fermentum quam.</li>
                        <li>Donec semper tempus enim.</li>
                         </ul>
                         <p ><a href="#" class="more">Readmore </a></p>
                         
                         <hr class="hr2" />
                  </div><!--subcolumns #end-->
                  
                  
                     <div class="subcolumns alignright ">
                       	 <h3>Article Title Here</h3>
                         <img src="<?php bloginfo('template_url'); ?>/images/article2.jpg" alt="" class="articleimg"  />
						<p> Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor.</p>
                        <ul>
                        <li>Quisque dapibus fermentum quam.</li>
                        <li>Donec semper tempus enim.</li>
                         </ul>
                         <p ><a href="#" class="more">Readmore </a></p>
                         
                         <hr class="hr2" />
                  </div><!--subcolumns #end-->
                    </div><!--main_columns #end-->
      
   
      
       
   
   
    
</div><!--content #end-->
 <?php /*remix_code_end*/ ?>  

 
<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>
 
<!--include footer-->
<?php get_footer(); ?>
