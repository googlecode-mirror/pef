<?php
/*
Template Name: Home 08

Sidebar: false
*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<div id="banner4">
  	<h2>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam</h2>
    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis ligula. Phasellus tristique purus a augue condimentum adipiscing. Aenean sagittis. Etiam leo pede, rhoncus venenatis, tristique in, vulputate at, odio.</p>
    <p ><a href="#" class="bold">Read More &raquo;</a></p>
</div><!--banner 4 #end -->
      <!--content #start -->
      <div id="content">
      	<?php /*remix_code_start*/ ?>
      
      		<div class="subcolumns alignleft">
            <img src="<?php bloginfo('template_url'); ?>/images/t9.png" alt=""  class="imgcenter" />
            <p class="bold">Lorem ipsum dolor sit amet </p>
			<p> consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus.</p>
            </div><!--subcolum #end -->
            
            <div class="subcolumns alignright">
            <img src="<?php bloginfo('template_url'); ?>/images/t10.png" alt=""  class="imgcenter" />
            <p class="bold">Lorem ipsum dolor sit amet </p>
			<p> consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus.</p>
            </div><!--subcolum #end -->
            
       </div><!--content #end-->
      
      
      
       <div id="sidebar">
      	<h2>Latest News</h2>
        <ul>
        	<?php $recent = new WP_Query("cat=$wpr_exclude_news&showposts=5"); while($recent->have_posts()) : $recent->the_post();?>
            <li><a href="<?php the_permalink(); ?>">
            <span class="bold"> <?php the_title(); ?> </span></a><br /> 
            <span class="date"> <?php the_time('j F, Y') ?>,  <?php the_time('g:i a') ?></span></li>
        <?php endwhile; ?>
        </ul>
       </div><!--sidebar #end-->
       
   <?php /*remix_code_end*/ ?>
    
<!--include footer-->
<?php get_footer(); ?>