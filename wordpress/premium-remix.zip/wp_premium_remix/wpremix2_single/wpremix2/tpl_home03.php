<?php
/*
Template Name: Home 03

Sidebar: false
*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
 <?php /*remix_code_start*/ ?>
 
    <div id="content2">
   	  <div class="latestpost">
         	 <img src="<?php bloginfo('template_url'); ?>/images/t2.png" alt="" class="imgleft"  />
             <h2><a href="#"><strong>This is a static content block</strong></a></h2>
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, ipsum dolor sit amet, consectetuer adipiscing elit fermentum id, molestie in, commodo  porttitor, felis. Maecenas urna purus, ipsum dolor sit amet. </p>
                  <p class="aright more"><a href="#">Read More</a></p>
         </div><!--latest post end -->
         
        
         <h4>Latest News</h4>
         <?php $page = (get_query_var('paged')) ? get_query_var('paged') : 1; query_posts("cat=$wpr_news&showposts=2&paged=$page"); while ( have_posts() ) : the_post()  ?>
            <div class="post"  id="post-<?php the_ID(); ?>">
           <h2><strong><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
            <?php the_title(); ?> </a></strong></h2>
          <p class="date"><?php the_time('j F, Y') ?>,  <?php the_time('g:i a') ?></p>      
          <?php the_excerpt(); ?>
          </div><!--post #end -->
         <?php endwhile; ?>    
    
         
          
          
	</div><!--content2 #end -->
        
    <div id="sidebar2">
   		 
         
          <!-- advertisement : your ads here -->
	 <?php include (TEMPLATEPATH . '/includes/ad/sidebar3_ad.php'); ?>
       
        <h4>Services</h4>
        
        <ul class="services">
        	<li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam.</li>
            <li>Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam ut lacus.</li>
            <li>Phasellus tristique purus a augue condimentum adipiscing. Aenean  sagittis. Etiam leo pede</li>
            <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam.</li>
            <li>Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit.</li>
          </ul>
         <p class="aright more"><a href="#">Read More</a></p>
        
    </div>
    
     
   <?php /*remix_code_end*/ ?>   
	
 <!--include footer-->
<?php get_footer(); ?>