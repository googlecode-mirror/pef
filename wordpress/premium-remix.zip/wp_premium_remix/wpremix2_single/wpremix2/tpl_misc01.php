<?php
/*
Template Name: Miscellaneous 01


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
 
	<!--content #start -->
      <div id="content">
      		   <h1 class="pagetitle"><?php the_title(); ?></h1>
                 <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis  ligula. Phasellus tristique purus a augue condimentum adipiscing.  Aenean  sagittis. Etiam leo pede, rhoncus venenatis, tristique in, vulputate at,  odio. Donec et ipsum et sapien vehicula nonummy. </p>
                 
                 <div class="testtimonials">
                  	<img src="<?php bloginfo('template_url'); ?>/images/f3.png" alt="" class="timg_left" />
                    <p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. </p>
					<p class="bold">- Roger Thomas</p>
                   </div><!--testimonials #end-->
                   
                    <div class="testtimonials">
                  	<img src="<?php bloginfo('template_url'); ?>/images/f3.png" alt="" class="timg_left" />
                    <p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. </p>
					<p class="bold">- Roger Thomas</p>
                   </div><!--testimonials #end-->
                   
                   
                   <div class="testtimonials">
                  	<img src="<?php bloginfo('template_url'); ?>/images/f3.png" alt="" class="timg_right" />
                    <p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. </p>
					<p class="bold">- Roger Thomas</p>
                   </div><!--testimonials #end-->

					<div class="testtimonials">
                  	<img src="<?php bloginfo('template_url'); ?>/images/f3.png" alt="" class="timg_right" />
                    <p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. </p>
					<p class="bold">- Roger Thomas</p>
                   </div><!--testimonials #end-->                
           
		</div><!--content #end-->
      
  <?php /*remix_code_end*/ ?>
    
 <!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>
      
<!--include footer-->
<?php get_footer(); ?>