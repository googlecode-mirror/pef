<?php
/*
Template Name: Inner Page 06


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
 
<!--content #start -->
      <div id="content">
      		   <h1 class="pagetitle"><?php the_title(); ?></h1>
                 <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis  ligula. Phasellus tristique purus a augue condimentum adipiscing.  Aenean  sagittis. Etiam leo pede, rhoncus venenatis, tristique in, vulputate at,  odio. Donec et ipsum et sapien vehicula nonummy. </p>
                
                
                   <ul class="service bgnone margin_auto">
               	  <li class="i_globe2 service_block"><strong>Lorem ipsum dolor site</strong> <br />
                  Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. </li>
                    <li class="i_pc service_block"><strong>Lorem ipsum dolor site</strong> <br />
                  Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. </li>
                   <li class="i_service2 service_block"><strong>Lorem ipsum dolor site</strong> <br />
                  Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum.  </li>
                  <li class="i_tools service_block"><strong>Lorem ipsum dolor site</strong> <br />
                  Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. </li>
                  <li class="i_lock service_block"><strong>Lorem ipsum dolor site</strong> <br />
                 Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum.</li>
                </ul><!--service #end-->
                
                <h3>Aenean tempus dignissim torto</h3>
                 <ul class="list_rounded">
                	<li>Quisque dapibus fermentum quam.</li>
                    <li>Donec semper tempus enim.</li>
                    <li>Aenean tempus dignissim tortor.</li>
                    <li>Ut condimentum. Mauris iaculis.</li>
                    <li>Quisque dapibus fermentum quam. Donec semper tempus enim.</li>
                    <li>Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis.</li>
                 </ul>
                 
                 <h3>Here's What you Get!</h3>
                 
                 <div class="twoby2 alignleft">
                 <p class="bold">Lorem ipsum dolor site amet</p>
				 <p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor. </p>
                 </div> <!--service #end-->
                 
                 <div class="twoby2 alignright">
                 <p class="bold">Lorem ipsum dolor site amet</p>
				 <p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor. </p>
                 </div><!--service #end-->
               
                   <div class="twoby2 alignleft">
                 <p class="bold">Lorem ipsum dolor site amet</p>
				 <p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor. </p>
                 </div> <!--service #end-->
                 
                 <div class="twoby2 alignright">
                 <p class="bold">Lorem ipsum dolor site amet</p>
				 <p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor. </p>
                 </div><!--service #end-->
             	
 </div><!--content #end-->
 <?php /*remix_code_end*/ ?>
     
      
 <!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar5.php'); ?>
       
<!--include footer-->
<?php get_footer(); ?>