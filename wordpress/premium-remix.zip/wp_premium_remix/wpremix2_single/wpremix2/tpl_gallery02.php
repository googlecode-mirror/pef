<?php
/*
Template Name: Gallery 02


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
 
<!--content #start -->
<div id="content">
   <h1 class="pagetitle"><?php the_title(); ?></h1>
	<p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor.</p>
    
        <ul class="gallery3">
        <li><a href="#"><strong>Template Name</strong></a> <br />
		<span class="small">Created by : <a href="#" >WP Remix </a></span>
		<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/g3.png" alt=""  /> </a>
        <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam</p>
          <a href="#" class="more" >More Details</a> </li>
        
        <li><a href="#"><strong>Template Name</strong></a> <br />
		<span class="small">Created by : <a href="#" >WP Remix </a></span>
		<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/g4.png" alt=""  /> </a>
        <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam</p>
         <a href="#" class="more" >More Details</a> </li>
        
        <li><a href="#"><strong>Template Name</strong></a> <br />
		<span class="small">Created by : <a href="#" >WP Remix </a></span>
		<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/g5.png" alt=""  /> </a>
        <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam</p>
           <a href="#" class="more" >More Details</a> </li>
        
        <li><a href="#"><strong>Template Name</strong></a> <br />
		<span class="small">Created by : <a href="#" >WP Remix </a></span>
		<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/g5.png" alt=""  /> </a>
        <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam</p>
           <a href="#" class="more" >More Details</a> </li>
        
       <li><a href="#"><strong>Template Name</strong></a> <br />
		<span class="small">Created by : <a href="#" >WP Remix </a></span>
		<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/g4.png" alt=""  /> </a>
        <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam</p>
           <a href="#" class="more" >More Details</a> </li>
        
        <li><a href="#"><strong>Template Name</strong></a> <br />
		<span class="small">Created by : <a href="#" >WP Remix </a></span>
		<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/g3.png" alt=""  /> </a>
        <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam</p>
           <a href="#" class="more" >More Details</a> </li>
       
  </ul>
 
</div><!--content #end-->
      
      <?php /*remix_code_end*/ ?> 
<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>
      
<!--include footer-->
<?php get_footer(); ?>