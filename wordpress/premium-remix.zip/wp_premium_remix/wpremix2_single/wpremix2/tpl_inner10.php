<?php
/*
Template Name: Inner Page 10


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
<!--content #start -->
<div id="content">

  <h1 class="pagetitle"><?php the_title(); ?></h1>
  <p class="clear">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam </p>
  
     <div class="box">
      <h3>Why you&rsquo;ll love WP Remix</h3>
    
     <ul class="download">
        <li><strong>Step 1 sit amet dolo site ame dolor site</strong> <br />
          consectetuer adipiscing elit. Praesent aliquam, 
          justo convallis luctus rutrum</li>
        <li><strong>Step 2 sit amet dolo site ame dolor site</strong> <br />
          consectetuer adipiscing elit. Praesent aliquam, 
          justo convallis luctus rutrum</li>
        <li><strong>Step 3sit amet dolo site ame dolor site</strong> <br />
          consectetuer adipiscing elit. Praesent aliquam, 
          justo convallis luctus rutrum</li>
        <li><strong>Step 4 sit amet dolo site ame dolor site</strong> <br />
          consectetuer adipiscing elit. Praesent aliquam, 
          justo convallis luctus rutrum</li>
        <li><strong>Step 5 dolor sit amet dolo site ame</strong> <br />
          consectetuer adipiscing elit. Praesent aliquam, 
          justo convallis luctus rutrum</li>
        <li><strong>Step 6 sit amet dolo site ame dolor site</strong> <br />
          consectetuer adipiscing elit. Praesent aliquam, 
          justo convallis luctus rutrum</li>
        <li><strong>Step 7 sit amet dolo site ame dolor site</strong> <br />
          consectetuer adipiscing elit. Praesent aliquam, 
          justo convallis luctus rutrum</li>
        <li><strong>Step 8 sit amet dolo site ame dolor site</strong> <br />
          consectetuer adipiscing elit. Praesent aliquam, 
          justo convallis luctus rutrum</li>
      </ul>
      
      <p class="clear">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam </p> 
      </div>
      
</div><!--content #end-->
<?php /*remix_code_end*/ ?>  

     <!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar4.php'); ?>

<!--include footer-->
<?php get_footer(); ?>
