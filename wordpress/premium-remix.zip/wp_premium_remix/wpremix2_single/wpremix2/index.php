<?php get_remix_header(); ?>

<div id="content-wrap" class="clear" >
<div id="blog_content">
 
<!-- This page currently show 7 posts (showposts=7) per page.  Change it to number of posts you want to display.-->
<?php $page = (get_query_var('paged')) ? get_query_var('paged') : 1; query_posts("showposts=7&paged=$page"); while ( have_posts() ) : the_post(); $loopcounter++; ?>
	
     <div  class="posts">
     		<div class="post_top"> 
                <div class="calendar"><?php the_time('j') ?> <br /><span class="month"><?php the_time('F') ?></span></div>
                <div class="pright">
            
                <h2 class="h1" id="post-<?php the_ID(); ?>">
                <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"> <?php the_title(); ?> </a></h2>
                <p>Posted by <span class="i_author"><?php the_author_posts_link(); ?></span>  
                <span class="i_comment2"><?php comments_popup_link('(0) Comment', '(1) Comment', '(%) Comment'); ?></span> </p> 
            </div><!-- pright #end -->
            </div><!--post_top #end -->
     
     		 <div class="clear">  
            <?php the_content('continue'); ?>
			<div class="post_paginate"><?php wp_link_pages(__('Pages:')); ?> </div>                    
            </div>
            
            <!--Rateing-->
            <?php if(function_exists('the_ratings')) { the_ratings(); } ?>
            <!--Rateing end-->
            
            	<div class="post_bottom"> <span class="cate"> Category : <?php the_category(' | ') ?></span>  
                	<ul class="bookmark">
                    	<li>Bookmark :</li>
                        <li class="i_digg">
                        <a href="http://www.digg.com/post?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">Digg</a></li>
                        <li class="i_del">
                        <a href="http://del.icio.us/post?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">del.icip.us</a></li>
                        <li class="i_stumbel">
                        <a href="http://www.stumbleupon.com/submit?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">
                        Stumbleupon</a></li>
                        <li class="i_redit">
                        <a href="http://reddit.com/submit?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">Redit it</a></li>
                	</ul>  
            	</div><!--post bottom #end-->
            
     </div><!--post #end-->

			 <!-- advertisement : your ads here -->
			<?php if ($loopcounter <= 1) { include (TEMPLATEPATH . '/includes/ad/blog_firstpost_ad.php'); } ?>

<?php endwhile; ?>
		

      <!-- Prev/Next page navigation -->
	<?php if(function_exists('wp_pagenavi')) { ?>
				<?php wp_pagenavi();  ?>
                <?php } 
     
     else {?>
    
                <div class="page-nav">
                <div class="nav-previous">
                <?php previous_posts_link('Previous Page') ?>
                </div>
                <div class="nav-next">
                <?php next_posts_link('Next Page') ?>
                </div>
                </div>


      <? } ?>

</div>

	<?php include(TEMPLATEPATH."/sidebar.php");?><!--include sidebar-->
    <?php get_footer(); ?><!--include footer-->