<?php
/*
Template Name: Product 04


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
<!--content #start -->
<div id="content">

  
  <h3>Product Title Goes Here </h3>
  
  <div id="product_detail">
      <div class="product_pic">
        <p><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/product1.png" alt="" border="0" /></a></p>
        <p><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/product_s3.png" alt="" border="0" /></a><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/product_s3.png" alt="" border="0"  /></a> <a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/product_s3.png" alt="" border="0"  /></a></p>
      </div>
      
      <div class="product_description">
       
        <div class="product_description_rating">
        <p><strong>Feature :</strong></p>
        <p>- by Seagate<br />
        - Manufacturer Part Number: ST9120801U2-RK<br />
        - Manufacturer Part Number <br />
        - Lorem ipusm dolor site amet</p>
        
          <p> <strong>by:</strong> Company Name <br />
            <strong>Manufacturer Part Number:</strong> ST9120801U2-RK</p>
          <p> <strong>Rating:</strong> 84/100<br />
            <strong>Price Range:</strong> $0,000 - $0000</p>
        </div>
        <p>Your Product Description Goes here.Taking your office on the road just got easier. Perfect for the extreme traveler, this drive is exceptionally durable with arobust, rugged design, inside and out. They even resist scuffs and scrapes.
        </p>
        <a href="#"  class="button">View Demo</a> <a href="#"  class="button">Add to Cart</a> 
      </div>
  </div>

      <h3 class="clear"><strong>Realated Product</strong></h3>
    <ul class="relatedproduct ">
      <li><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/product_s4.png" alt="" class="img" />
      <strong>Product Name</strong></a> <br /> Price : $22</li>   
      <li><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/product_s4.png" alt="" class="img" />
      <strong>Product Name</strong></a> <br /> Price : $22</li>    
      <li><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/product_s4.png" alt="" class="img" />
      <strong>Product Name</strong></a> <br /> Price : $22</li>    
      <li><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/product_s4.png" alt="" class="img" />
      <strong>Product Name</strong></a> <br /> Price : $22</li>    
  </ul>
  
    
</div><!--content #end-->
 
 <?php /*remix_code_end*/ ?>

<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>
 
<!--include footer-->
<?php get_footer(); ?>
