<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/advt2.png" alt="" width="240" height="200" class="ads"  /></a> 

