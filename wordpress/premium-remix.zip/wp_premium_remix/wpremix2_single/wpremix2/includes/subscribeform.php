<?php
global $options;
foreach ($options as $value) {
		global $$value['id'];
        if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
?>

<form action="http://www.feedburner.com/fb/a/emailverify" method="post" target="popupwindow" onSubmit="window.open('http://www.feedburner.com/fb/a/emailverifySubmit?feedId=<?php echo $wpr_feedburner_id; ?>', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true">
  <input name="email" type="text" value="Your Email Address" class="subtextield" onFocus="if (this.value == 'Your Email Address') {this.value = '';}" onBlur="if (this.value == '') {this.value = 'Your Email Address';}" />
   <input type="hidden" value="http://feeds.feedburner.com/~e?ffid=<?php echo $wpr_feedburner_id; ?>" name="url"/>
  <input type="hidden" value="<?php bloginfo('name'); ?>" name="title"/>
  <input type="hidden" name="loc" value="en_US"/>
  <input type="image" src="<?php bloginfo('template_url'); ?>/images/b_go.png"   value=""  />
</form>