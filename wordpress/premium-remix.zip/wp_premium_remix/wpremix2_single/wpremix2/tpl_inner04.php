<?php
/*
Template Name: Inner Page 04


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
 
<!--content #start -->
      <div id="content">
      		   <h1 class="pagetitle"><?php the_title(); ?></h1>
                <!--start -->           
              <img src="<?php bloginfo('template_url'); ?>/images/s1.jpg" alt=""  class="imgright"   />
             <p class="bold"> Lorem ipsum dolor site amet</p>
			<p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor. Quisque dapibus fermentum quam. </p>
     			
           <hr class="hr2 showcase_spcaer" /> <!--#end -->    
           
           
            <!--start -->           
              <img src="<?php bloginfo('template_url'); ?>/images/s2.jpg" alt=""  class="imgright"   />
             <p class="bold"> Lorem ipsum dolor site amet</p>
			<p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor. Quisque dapibus fermentum quam. </p>
     			
           <hr class="hr2 showcase_spcaer" /> <!--#end -->    
           
           
           
            <!--start -->           
              <img src="<?php bloginfo('template_url'); ?>/images/s1.jpg" alt=""  class="imgleft"   />
             <p class="bold"> Lorem ipsum dolor site amet</p>
			<p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor. Quisque dapibus fermentum quam. </p>
     			
           <hr class="hr2 showcase_spcaer" /> <!--#end -->    
           
            <!--start -->           
              <img src="<?php bloginfo('template_url'); ?>/images/s2.jpg" alt=""  class="imgleft"   />
             <p class="bold"> Lorem ipsum dolor site amet</p>
			<p>Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor. Quisque dapibus fermentum quam. </p>
     			
           <hr class="hr2 showcase_spcaer" /> <!--#end -->  
           
           
           <h3>Sub heading here </h3>
           
           
           <div class="showcase alignleft">
                <img src="<?php bloginfo('template_url'); ?>/images/s2.jpg" alt=""  class="imgf_right"   />
             <div class="scontent alignleft"><p class="bold"> Lorem ipsum dolor site amet</p>
			<p>Quisque dapibus fermentum quam. Donec semper tempus</p>
            </div><!--showcase #end-->
             <hr class="hr2 showcase_spcaer" /> <!--#end -->  
             
             
               <img src="<?php bloginfo('template_url'); ?>/images/s1.jpg" alt=""  class="imgf_right"   />
             <div class="scontent alignleft"><p class="bold"> Lorem ipsum dolor site amet</p>
			<p>Quisque dapibus fermentum quam. Donec semper tempus</p>
            </div><!--showcase #end-->
             <hr class="hr2 showcase_spcaer" /> <!--#end -->  
             
               <img src="<?php bloginfo('template_url'); ?>/images/s2.jpg" alt=""  class="imgf_right"   />
             <div class="scontent alignleft"><p class="bold"> Lorem ipsum dolor site amet</p>
			<p>Quisque dapibus fermentum quam. Donec semper tempus</p>
            </div><!--showcase #end-->
             <hr class="hr2 showcase_spcaer" /> <!--#end -->  
           
           </div><!--showcase #end-->
           
           
            <div class="showcase alignright">
                <img src="<?php bloginfo('template_url'); ?>/images/s2.jpg" alt=""  class="imgf_right"   />
             <div class="scontent alignleft"><p class="bold"> Lorem ipsum dolor site amet</p>
			<p>Quisque dapibus fermentum quam. Donec semper tempus</p>
            </div><!--showcase #end-->
             <hr class="hr2 showcase_spcaer" /> <!--#end -->  
             
             
               <img src="<?php bloginfo('template_url'); ?>/images/s1.jpg" alt=""  class="imgf_right"   />
             <div class="scontent alignleft"><p class="bold"> Lorem ipsum dolor site amet</p>
			<p>Quisque dapibus fermentum quam. Donec semper tempus</p>
            </div><!--showcase #end-->
             <hr class="hr2 showcase_spcaer" /> <!--#end -->  
             
               <img src="<?php bloginfo('template_url'); ?>/images/s2.jpg" alt=""  class="imgf_right"   />
             <div class="scontent alignleft"><p class="bold"> Lorem ipsum dolor site amet</p>
			<p>Quisque dapibus fermentum quam. Donec semper tempus</p>
            </div><!--showcase #end-->
             <hr class="hr2 showcase_spcaer" /> <!--#end -->  
           
           </div><!--showcase #end-->
 <?php /*remix_code_end*/ ?>
          
             
</div><!--content #end-->
      
      
<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar2.php'); ?>
      
<!--include footer-->
<?php get_footer(); ?>