<?php
/*
Template Name: Home 05

Sidebar: false
*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
  	<div id="main">
    <?php /*remix_code_start*/ ?>
    	<div class="project">
        	 
             <img src="<?php bloginfo('template_url'); ?>/images/p1.jpg" alt=""  />
             
            <div class="pcontent">
             <h2 class="title">Featured Static Block</h2>
             <h2><a href="#">Project Name</a></h2>
             <p>This block features a static content block. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis  ligula. Phasellus tristique purus a augue condimentum adipiscing. Aenean  sagittis. Etiam leo pede, rhoncus venenatis, tristique in, vulputate at,  odio. </p>
             </div>
        </div><!--project #end -->
    </div><!--main #end-->
 
     <div id="content">
     	<h3 class="newstitle"> News &amp; updates </h3>
         <?php $page = (get_query_var('paged')) ? get_query_var('paged') : 1; query_posts("cat=$wpr_news&showposts=1&paged=$page"); while ( have_posts() ) : the_post()  ?>
    
     <h2 class="newshead"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
        <?php the_title(); ?></a></h2>
        <p class="ptop">Posted by <?php the_author_posts_link(); ?> at  <?php the_time('j F, Y') ?>,  <?php the_time('g:i a') ?>  </p>
        
         <?php the_content('continue'); ?>
    
	  <?php endwhile; ?>
     	
    </div><!--content #end -->

    <div id="sidebar">
     	<h2 class="subtitle">The Company </h2>
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis  ligula. Phasellus tristique .</p>
     </div><!--sidebar #end -->
     
     
     <div id="latestwork" >
     <h2>Our Latest Work</h2>
     
     <ul class="projectlist">
     <li><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/p2.jpg" alt=""  /> Project Name Here</a></li>
     <li><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/p3.jpg" alt=""  /> Project Name Here</a></li>
     <li><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/p4.jpg" alt=""  /> Project Name Here</a></li>
     <li><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/p5.jpg" alt=""  /> Project Name Here</a></li>
     </ul>
      </div><!--latest work end -->
      
      
      <div class="alllinks alignleft">
      	<h2>My Links</h2>
      	<ul class="mylinks ">
        	<li><a href="#">Lorem ipsum dolor sit amet</a></li>
            <li><a href="#">consectetuer adipiscing elit. </a></li>
            <li><a href="#">Praesent aliquam,  justo conva</a></li>
            <li><a href="#">lis luctus rutrum, erat nulla </a></li>
            <li><a href="#">fermentum diam, at nonummy </a></li>
            <li><a href="#">quam  ante ac quam.</a></li>
            <li><a href="#">Lorem ipsum dolor sit amet</a></li>
            <li><a href="#">consectetuer adipiscing elit. </a></li>
            <li><a href="#">Praesent aliquam,  justo conva</a></li>
            <li><a href="#">lis luctus rutrum, erat nulla </a></li>
            <li><a href="#">fermentum diam, at nonummy </a></li>
            <li><a href="#">quam  ante ac quam.</a></li>
        </ul>      	
      </div><!--all links #end-->
      
      <div class="alllinks alignright">
      	<h2>Other Links</h2>
      	<ul class="mylinks ">
        	<li><a href="#">Lorem ipsum dolor sit amet</a></li>
            <li><a href="#">consectetuer adipiscing elit. </a></li>
            <li><a href="#">Praesent aliquam,  justo conva</a></li>
            <li><a href="#">lis luctus rutrum, erat nulla </a></li>
            <li><a href="#">fermentum diam, at nonummy </a></li>
            <li><a href="#">quam  ante ac quam.</a></li>
            <li><a href="#">Lorem ipsum dolor sit amet</a></li>
            <li><a href="#">consectetuer adipiscing elit. </a></li>
            <li><a href="#">Praesent aliquam,  justo conva</a></li>
            <li><a href="#">lis luctus rutrum, erat nulla </a></li>
            <li><a href="#">fermentum diam, at nonummy </a></li>
            <li><a href="#">quam  ante ac quam.</a></li>
        </ul>      	
      </div><!--all links #end-->
      
       <?php /*remix_code_end*/ ?>
     
  
<!--include footer-->
<?php get_footer(); ?>