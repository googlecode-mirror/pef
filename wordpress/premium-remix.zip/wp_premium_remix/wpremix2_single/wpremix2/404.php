<?php get_remix_header(); ?>
<!--create your own error 404 page-->
<div id="content-wrap">
<div id="blog_content">
  <h3>Sorry, no posts matched your criteria.</h3>
    <p>Please try searching again here...</p>
    <div class="search404 clear"> 
         <?php include(TEMPLATEPATH."/searchform.php");?>
    </div>
    <p><strong>Or, take a look at Archives and Categories</strong></p>
     
    <div class="category">
    	<h2 class="error_title"><?php _e('Category'); ?></h2>
    	<ul>
        <?php wp_list_categories('orderby=name&title_li'); ?>
      </ul>
    </div>
    
    <div class="archives"> 
     <h2 class="error_title">
      <?php _e('Archives'); ?>
    </h2>
    <ul>
      <?php wp_get_archives('type=monthly'); ?>
    </ul>
     </div>
</div>
<!--include sidebar-->
<?php include(TEMPLATEPATH."/sidebar.php");?><!--include sidebar-->
<!--include footer-->
<?php get_footer(); ?>