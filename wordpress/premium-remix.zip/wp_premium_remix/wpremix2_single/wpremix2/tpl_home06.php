<?php
/*
Template Name: Home 06

Sidebar: false
*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
 <?php /*remix_code_start*/ ?>
 
   	<div id="banner3">
      <div class="b3content">
        <h2>Your Site's Main Punchline comes here! dolor site amet disate <span class="black"> Praesent aliquam, </span> justo convallis luctus rutrum. </h2>
        <p>The secondary text explaining your site/business purpose like what and how it does etc. Below are the few options that you could use to highlight main features of your site/business. </p>
        <a href="#"  class="button alignright" >getstarted now</a>
    </div><!--b3conten now-->

    </div><!--banner3 #end -->
    
    
<div id="threecoulums">

	<!--threecolumns-in start-->
    <div class="threecolumns-in alignleft">
     <h2>About Us</h2>
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis.Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis.  </p>
        <p>Donec et ipsum et sapien vehicula nonummy. Suspendisse potenti. Fusce  varius urna id quam. Sed neque mi, varius eget, tincidunt nec, suscipit id,  libero. In eget purus. Vestibulum ut nisl. </p>
    </div><!--3columns innner #end -->
    
    
    <!--threecolumns-in start-->
    <div class="threecolumns-in alignleft threespcaer">
     <h2>Photos</h2>
          	  <div class="flickr">
         
          <?php
global $options;
foreach ($options as $value) {
		global $$value['id'];
        if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
?>
         <script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=10&amp;display=latest&amp;size=s&amp;source=user&amp;user=<?php echo $wpr_flickr_id; ?>"></script>
         </div>
             
      <div class="testimonials">
       	<h2>Testimonials</h2>
             <!-- dyanamic testimonials-->  
			 <?php include (TEMPLATEPATH . "/includes/testimonials.php"); ?>
             <!--# end-->               
      </div>
             
    </div><!--3columns innner #end -->
    
    
 <div id="sidebar">
 	<h2 class="threetitle">Services</h2>
    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante.</p>
    
    
     <h2 class="threetitle">Latest News</h2>
    
    <ul>
    	 <?php $recent = new WP_Query("cat=$wpr_exclude_news&showposts=5"); while($recent->have_posts()) : $recent->the_post();?>
        <li><a href="<?php the_permalink(); ?>">
          <?php the_title(); ?>
          </a> </li>
        <?php endwhile; ?>
    </ul>
    
 </div>  
    
    
</div><!--3columns outer #end -->
    <?php /*remix_code_end*/ ?>


<!--include footer-->
<?php get_footer(); ?>