<?php
/*
Template Name: Home 01

Sidebar: false
*/
?><?php get_remix_header(); ?>

<div id="banner">
  <div id="banner-in">
     <div class="content">
       	<h2>  Your Site's Main Punchline comes here! </h2>
        <p>The secondary text explaining your site/business purpose like what and how it does etc. Below are the few options that you could use to highlight main features of your site/business.</p>
        <ul class="option">
            <li class="i_feature1"><a href="#">Feature 1</a><br /> Descprition text goes here</li>
            <li class="i_feature2"><a href="#">Feature 2 text</a><br /> Descprition text goes here</li>
            <li class="i_feature3"><a href="#">Feature 3 Title</a><br /> Descprition text goes here</li>
            <li class="i_feature4"><a href="#">Feature 4 Title</a><br /> Descprition text goes here</li>
        </ul>
        <div><a href="#" class="button alignright">Get Started Now</a></div>
     </div><!--content end -->
    
     
  </div>
</div>
<!--banner end -->

<div id="content-wrap"  >
	<div id="content">
    <?php /*remix_code_start*/ ?>
    <!--sub colums start-->
    
     	<div class="subcolumns alignleft">
        	<h3>About Us </h3>
             <p>Use this block to introduce a bit in deeper about you/business. Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. Vivamus ligula nisi, dictum vel, elementum eget, cursus quis, tortor.</p>
<p>Quisque dapibus fermentum quam. Donec semper tempus enim.  </p>
			<div id="subscribe">
            	<p class="bold i_email">Subscribe Via Email </p>
             		
                 <?php include (TEMPLATEPATH . "/includes/subscribeform.php"); ?>
             </div><!--subscribe end -->
        </div><!--subcolum #end -->
        
 <!--sub colums start-->
     	<div class="subcolumns alignright">
        	<h3>Featured</h3>
             <img src="<?php bloginfo('template_url'); ?>/images/t1.png" alt="" class="imgborder"  />
 			 	<div class="testimonials">
                	  <!-- dyanamic testimonials-->  
					 <?php include (TEMPLATEPATH . "/includes/testimonials.php"); ?>
                     <!--# end-->  
                </div>
        </div><!--subcolum #end -->
        
        
    </div><!--content #end -->
    
    <div id="sidebar">
    	 <h3>News &amp; Events</h3>
          <ul>
         	 <?php $recent = new WP_Query("cat=$wpr_exclude_news&showposts=7"); while($recent->have_posts()) : $recent->the_post();?>
        <li><a href="<?php the_permalink(); ?>">
          <?php the_title(); ?>
          </a> </li>
        <?php endwhile; ?>
         </ul>
     </div><!--sidebar #end -->
    <?php /*remix_code_end*/ ?>
 <!--include footer-->
<?php get_footer(); ?>