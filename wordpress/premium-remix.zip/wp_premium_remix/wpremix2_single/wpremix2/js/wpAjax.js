/* <![CDATA[ */
	wpAjax = {
		noPerm: "You do not have permission to do that.",
		broken: "An unidentified error has occurred."
	}
/* ]]> */