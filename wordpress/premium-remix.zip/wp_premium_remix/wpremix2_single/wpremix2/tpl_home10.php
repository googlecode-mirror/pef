<?php
/*
Template Name: Home 10

Sidebar: false
*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">

<div id="banner9">
  <ul class="option9">
    <li class="i_feature1"><a href="#">Feature Title 1 </a><br />Description text goes here</li>
    <li class="i_feature2"><a href="#">Feature Title 2 </a><br />Description text goes here</li>
    <li class="i_feature3"><a href="#">Feature Title 3</a><br />Description text goes here</li>
    <li class="i_feature4"><a href="#">Feature Title 4</a><br />Description text goes here</li>
  </ul>

  <h2> Your Site's Main Punchline comes here! Aenean tempus dignissim tortor. Ut condimentum. Mauris iaculis. </h2>
  <p> the secondary text explaining your site/business purpose like what and how it does etc. Below are the few options that you could use to highlight main features of your site/business. cursus quis, tortor. Nulla pede.</p>
</div>
<!--Banner End-->


    
      <!--content #start -->
      <div id="content">
        <?php /*remix_code_start*/ ?>
      		<div class="subcolumns alignleft">
             <h3>Services </h3>
             <p> consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus. commodo porttitor, felis. Nam blandit quam ut lacus lorem ipsum dolor site amet. </p>
    <ul class="links">
        <li>Praesent aliquam, justo convallis</li>
        <li>Nam blandit quam ut lacus</li>
        <li>Araesent aliquam, justo convallis</li>
        <li>Nam blandit quam ut lacus</li>
    </ul>
   
  
            </div><!--subcolum #end -->
            
            <div class="subcolumns alignright">
             <h3>Our Company </h3>
             
                 <img src="<?php bloginfo('template_directory'); ?>/images/t11.png" alt=""  class="imgcenter" />
             
			<p> Nam blandit quam ut lacus. commodo porttitor, felis. Nam blandit quam ut lacus lorem ipsum dolor site amet. ipsum dolor site amet. </p>
            
            </div><!--subcolum #end -->
            
             
            
      </div><!--content #end-->
      
      
      
       <div id="sidebar">
      	<h2>Latest News</h2>
       
        <ul>
        	<?php $recent = new WP_Query("cat=$wpr_exclude_news&showposts=5"); while($recent->have_posts()) : $recent->the_post();?>
            <li><a href="<?php the_permalink(); ?>">
            <span class="bold"> <?php the_title(); ?> </span></a><br /> 
            <span class="date"> <?php the_time('j F, Y') ?>,  <?php the_time('g:i a') ?></span></li>
        <?php endwhile; ?>
        </ul>
      
      </div><!--sidebar #end-->
      
        <?php /*remix_code_end*/ ?>
    
<!--include footer-->
<?php get_footer(); ?>