<?php
/*
Template Name: Inner Page 13

Sidebar: false
*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
<!--content #start -->
<div id="main">

  <h1 class="pagetitle"><?php the_title(); ?></h1>
   <img src="<?php bloginfo('template_url'); ?>/images/w1.png" alt="" class="imgright"  />
  
  <p class="captial">Worem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis ligula. Phasellus tristique purus a augue condimentum adipiscing. Aenean sagittis. Etiam leo pede, rhoncus venenatis, tristique in, vulputate at, odio. Donec et ipsum et sapien vehicula nonummy. Suspendisse potenti. Fusce varius urna id quam. Sed neque mi, varius eget, tincidunt nec, suscipit id, libero. In eget purus. Vestibulum ut nisl. Donec eu mi sed turpis feugiat feugiat. Integer turpis arcu, pellentesque eget, cursus et, fermentum ut, sapien.</p>
  
   
 <h3 class="clear">Lorem ipusm dolor site amet</h3>
  
  <div class="columns3 alignleft">
  	<h3>Lorem ipsum dolor sit amet</h3>
    <img src="<?php bloginfo('template_url'); ?>/images/w1.png" alt="" class="columns_img"  />
    <p>Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis ligula.</p>
  </div><!--columns3 #end-->
  
  
  <div class="columns3 alignleft columns_spacer">
  	<h3>Lorem ipsum dolor sit amet</h3>
      <img src="<?php bloginfo('template_url'); ?>/images/w2.png" alt="" class="columns_img"  />
    <p>Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis ligula.</p>
  </div><!--columns3 #end-->
  
  
  <div class="columns3 alignright">
  	<h3>Lorem ipsum dolor sit</h3>
    <img src="<?php bloginfo('template_url'); ?>/images/w1.png" alt="" class="columns_img"  />
    <p>Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis ligula.</p>
  </div><!--columns3 #end-->
   
 </div><!--main #end-->
 <?php /*remix_code_end*/ ?>  

<!--include footer-->
<?php get_footer(); ?>
