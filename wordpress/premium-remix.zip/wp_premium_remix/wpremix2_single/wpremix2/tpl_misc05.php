<?php
/*
Template Name: Miscellaneous 05


*/
?>
<?php get_remix_header(); ?>

 
<div id="content-wrap" class="clear" >
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
 
<!--content #start -->
<div id="content">
   <h1 class="pagetitle"><?php the_title(); ?></h1>
  
   <div class="sitemap alignleft">
    	  <div class="sitemap_list">
       <h3>Pages</h3>
           <ul class="feature">
            <?php wp_list_pages('title_li='); ?>
        </ul>
        </div><!--product #end-->
        
        
        <div class="sitemap_list alignleft">
        	<h3>Archives</h3>
          <ul class="feature">
           <?php wp_get_archives('type=monthly'); ?>
        </ul>
         </div><!--product #end-->
        
        
        <div class="sitemap_list alignright">
        		<h3>Categories</h3>
        
         <ul class="feature">
            <?php wp_list_cats('sort_column=name'); ?>
        </ul>
        
         </div><!--product #end-->
        
     </div><!--sitemap_listlist #end -->
  
  
</div>
<!--include sidebar-->
<?php /*remix_code_end*/ ?>   

<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>
 
  <!--include footer-->
<?php get_footer(); ?>
