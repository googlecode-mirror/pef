<?php //Begin widget code
if ( function_exists('register_sidebars') )
    register_sidebars(2);
?>
<?php
$themename = "WP Remix 2.0";
$shortname = "wpr";
$options = array (
    
array(	"name" => "General Settings",
		"type" => "heading"),
		
    array(  "name" => "Your Feedburner ID",
			"desc" => "Specify Your Feedburner ID here. To find out what your Feedburner ID is, check ThemeGuide PDF shipped with the theme ",
            "id" => $shortname."_feedburner_id",
            "std" => "",
            "type" => "text"),
			
    array(  "name" => "Your Flickr ID",
			"desc" => "Specify Your Flickr ID here - Use the <a href='http://idgettr.com'>idGettr</a> to find your id.",
            "id" => $shortname."_flickr_id",
            "std" => "88392804@N00",
            "type" => "text"),
					
    array(  "name" => "Home Page news",
			"desc" => "Specify from which categories, images in Homepage news should be displayed",
            "id" => $shortname."_news",
            "std" => "6",
            "type" => "text"),
			
   array(  "name" => "Home - Featured",
		"desc" => "Specify from which categories, images in Homepage Featured should be displayed",
		"id" => $shortname."_featured",
		"std" => "8",
		"type" => "text"),

    array(  "name" => "Home - Exclude from Latest News",
			"desc" => "If blog updates from some categories need to be EXCLUDED in latest news in homepage, specify category ids (e.g. -1, -15)",
            "id" => $shortname."_exclude_news",
            "std" => "-6",
            "type" => "text"),

	array(  "name" => "Theme Color Change",
			"desc" => "Specify primary color that will be used for normal text",
            "id" => $shortname."_body_color",
            "std" => "grey",
            "type" => "select",
			"options" => array("default", "blue", "pink", "lavender", "yellow", "green")),

);


function mytheme_add_admin() {

    global $themename, $shortname, $options;

    if ( $_GET['page'] == basename(__FILE__) ) {
    
        if ( 'save' == $_REQUEST['action'] ) {
								update_option('remix-global-header',$_REQUEST['remix-global-header']);

                foreach ($options as $value) {
                    update_option( $value['id'], $_REQUEST[ $value['id'] ] ); }

                foreach ($options as $value) {
                    if( isset( $_REQUEST[ $value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); } else { delete_option( $value['id'] ); } }

                header("Location: themes.php?page=functions.php&saved=true");
                die;

        } else if( 'reset' == $_REQUEST['action'] ) {

            foreach ($options as $value) {
                delete_option( $value['id'] ); }

            header("Location: themes.php?page=functions.php&reset=true");
            die;

        }
    }

    add_theme_page($themename." Options", "Current Theme Options", 'edit_themes', basename(__FILE__), 'mytheme_admin');

}

function mytheme_admin() {

    global $themename, $shortname, $options;

    if ( $_REQUEST['saved'] ) echo '<div id="message" class="updated fade"><p><strong>'.$themename.' settings saved.</strong></p></div>';
    if ( $_REQUEST['reset'] ) echo '<div id="message" class="updated fade"><p><strong>'.$themename.' settings reset.</strong></p></div>';
    
?>

<div class="wrap">
<h2><?php echo $themename; ?> settings</h2>
<form method="post">
  <table class="optiontable">
    <?php foreach ($options as $value) {
    
if ($value['type'] == "heading") { ?>
		<tr valign="top"> 
		    <td colspan="2"><h3 style=" font:bold 15px Tahoma; border-bottom:1px solid #0C6; color: #090"><?php echo $value['name']; ?></h3></td>
		</tr>

    <?php } elseif ($value['type'] == "text") { ?>

    <tr valign="top">
      <th scope="row" style="font:bold 11px Verdana, Arial, Helvetica, sans-serif; padding-top:10px;"><?php echo $value['name']; ?>:</th>
      <td><input name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo get_settings( $value['id'] ); } else { echo $value['std']; } ?>" />
        <br />
        <small><?php echo $value['desc'] ; ?></small> </td>
    </tr>

    <?php } elseif ($value['type'] == "select") { ?>
    <tr valign="top">
      <th scope="row" style="font:bold 11px Verdana; padding-top:10px;"><?php echo $value['name']; ?>:</th>
      <td style="font:11px Verdana, Arial, Helvetica, sans-serif;"><select name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
          <?php foreach ($value['options'] as $option) { ?>
          <option<?php if ( get_settings( $value['id'] ) == $option) { echo ' selected="selected"'; } elseif ($option == $value['std']) { echo ' selected="selected"'; } ?>><?php echo $option; ?></option>
          <?php } ?>
        </select>
        <br />
        <small><?php echo $value['desc'] ; ?></small> </td>
    </tr>
    <?php
}
}
global $remix_advanced_editor;
if (!empty($remix_advanced_editor)) {
?>
<tr valign="top">
<th scope="row" style="font:bold 11px Verdana; padding-top:10px;">Global Header:</th>
<td style="font:11px Verdana, Arial, Helvetica, sans-serif;"><select name="remix-global-header" id="remix-global-header">
<?php
	$headerOptions = $remix_advanced_editor->get_page_options("header");
	ksort($options);
	$selected = get_option('remix-global-header');
	if ($headerOptions) {
		foreach($headerOptions as $header) {
			$sel = '';
			if (trim($header) == $selected) {
				$sel = "selected='selected'";
			}
			?>
			<option value='<?php echo trim($header) ?>' <?php echo $sel ?>><?php echo trim($header) ?></option>
			<?php
		}
	}
?></select>
<br />Select a header you would like applied to the entire site.
</td>
    </tr>
<?
}
?>

  </table>
  <p class="submit">
    <input name="save" type="submit" value="Save changes" />
    <input type="hidden" name="action" value="save" />
  </p>
</form>
<form method="post">
  <p class="submit">
    <input name="reset" type="submit" value="Reset" />
    <input type="hidden" name="action" value="reset" />
  </p>
</form>
<?php
}
function get_remix_header() {
		//Header
		$rheader = get_option('remix-global-header');
		if ($rheader) {
			if (file_exists(TEMPLATEPATH . '/includes/header/' . $rheader . ".php")) {
				include(TEMPLATEPATH . '/includes/header/' . $rheader . ".php");
			} else {
				include (TEMPLATEPATH . '/includes/header/header1.php');
			}
		} else {
			include (TEMPLATEPATH . '/includes/header/header1.php');
		}
}
function remix_add_scripts() {
	wp_enqueue_script('jquery');
	wp_enqueue_script('remix_faq', get_bloginfo('template_directory') . '/js/faq.js', array("jquery", ) , 1.0);
}
function mytheme_wp_head() { ?>
<link href="<?php bloginfo('template_directory'); ?>/style.php" rel="stylesheet" type="text/css" />
<?php }
add_action('wp_head', 'mytheme_wp_head');
add_action('admin_menu', 'mytheme_add_admin'); 
add_action('wp_print_scripts','remix_add_scripts');
//Remix Editor
include(TEMPLATEPATH . "/editor/remix_advanced_editor.php");
?>