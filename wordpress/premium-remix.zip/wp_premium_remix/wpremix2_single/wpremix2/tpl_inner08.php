<?php
/*
Template Name: Inner Page 08


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>

	<!--content #start -->
      <div id="content">
      		   <h1 class="pagetitle"><?php the_title(); ?></h1>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam ut lacus.  Dolor site amet aecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam ut lacus. </p>
                
                <ul class="service">
               	  <li class="i_globe2"><strong>Lorem ipsum dolor site</strong> <br />
                  Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. </li>
                  <li class="i_floder"><strong>Lorem ipsum dolor site</strong> <br />
                  Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. </li>
                  <li class="i_about"><strong>Lorem ipsum dolor site</strong> <br />
                  Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. </li>
                  <li class="i_camera"><strong>Lorem ipsum dolor site</strong> <br />
                  Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. </li>
                   <li class="i_pc"><strong>Lorem ipsum dolor site</strong> <br />
                  Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. </li>
                   <li class="i_service2"><strong>Lorem ipsum dolor site</strong> <br />
                  Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. </li>
                  <li class="i_tools"><strong>Lorem ipsum dolor site</strong> <br />
                  Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. </li>
                  <li class="i_lock"><strong>Lorem ipsum dolor site</strong> <br />
                  Quisque dapibus fermentum quam. Donec semper tempus enim. Aenean tempus dignissim tortor. </li>
                </ul>
             
		</div><!--content #end-->
 <?php /*remix_code_end*/ ?>
     
<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar4.php'); ?>

<!--include footer-->
<?php get_footer(); ?>