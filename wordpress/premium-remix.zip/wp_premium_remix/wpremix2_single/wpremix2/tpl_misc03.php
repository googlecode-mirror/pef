<?php
/*
Template Name: Miscellaneous 03


*/
?>

<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
 
<!--content #start -->
<div id="content">
   <h1 class="pagetitle"><?php the_title(); ?></h1>
  
<ol class="message_list">
    <li>
		<p class="message_head">Support </p>
		<div class="message_body">
			 <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.  </p>
		</div>
        
        <p class="message_head message_subhead">Q.1 Consectetuer adipiscing elit?</p>
		<div class="message_body">
			 <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis.</p>
		</div>
        
        <p class="message_head message_subhead">Q.2 Lorem ipsum Consectetuer adipiscing elit?</p>
		<div class="message_body">
			 <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis.</p>
		</div>
        
         <p class="message_head message_subhead">Q.3 Adipiscing elit Consectetuer adipiscing elit?</p>
		<div class="message_body">
			 <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis.</p>
		</div>
        
        <hr class="hr3" />
 	</li>
    
    <li>
		<p class="message_head">Sales </p>
		<div class="message_body">
			 <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.  </p>
		</div>
        
        <p class="message_head message_subhead">Q.1 Consectetuer adipiscing elit?</p>
		<div class="message_body">
			 <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis.</p>
		</div>
        
        <p class="message_head message_subhead">Q.2 Lorem ipsum Consectetuer adipiscing elit?</p>
		<div class="message_body">
			 <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis.</p>
		</div>
        
         <p class="message_head message_subhead">Q.3 Adipiscing elit Consectetuer adipiscing elit?</p>
		<div class="message_body">
			 <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis.</p>
		</div>
        
        <hr class="hr3" />
 	</li>
	  
      <li>
		<p class="message_head">Marketing </p>
		<div class="message_body">
			 <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit paesent aliquam,  justo convallis  </p>
		</div>
        
        <p class="message_head message_subhead">Q.1 Consectetuer adipiscing elit?</p>
		<div class="message_body">
			 <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis.</p>
		</div>
        
        <p class="message_head message_subhead">Q.2 Lorem ipsum Consectetuer adipiscing elit?</p>
		<div class="message_body">
			 <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis.</p>
		</div>
        
         <p class="message_head message_subhead">Q.3 Adipiscing elit Consectetuer adipiscing elit?</p>
		<div class="message_body">
			 <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis.</p>
		</div>
        <hr class="hr3" />
 	</li>
 </ol>
</div><!--content #end-->
    <?php /*remix_code_end*/ ?>            
  
      
<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>
      
<!--include footer-->
<?php get_footer(); ?>