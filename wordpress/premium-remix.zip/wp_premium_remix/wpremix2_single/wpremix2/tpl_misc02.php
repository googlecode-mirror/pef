<?php
/*
Template Name: Miscellaneous 02


*/
?>
<?php get_remix_header(); ?>
<?php /*remix_code_start*/ ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/taber.js"></script>
<script type="text/javascript">
/* Optional: Temporarily hide the "tabber" class so it does not "flash"
   on the page as plain HTML. After tabber runs, the class is changed
   to "tabberlive" and it will appear. */
document.write('<style type="text/css">.tabber{display:none;}<\/style>');
</script>

<div id="content-wrap">
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
 
<!--content #start -->
      <div id="content">
      		   <h1 class="pagetitle"><?php the_title(); ?></h1>
             	 <div class="tabber">
      <div class="tabbertab">
        <h2>Tab Option 1 </h2>
        
        <p class="bold">Lras condimentum feugiat sed Suspendisse elementum </p>
        <p> <img src="<?php bloginfo('template_directory'); ?>/images/f2.png" alt=""  class="imgleft" />Suspendisse elementum, <a href="#">justo at elementum</a> consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed </p>
        <blockquote class="clear"> Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed  Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed </blockquote>
        
        
        <p class="bold">Suspendisse elementum,  consectetuer, tellus neque pretium nisi, </p>
        <p>quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed </p>
        <p>Tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed </p>
      <p><strong>Suspendisse elementum,  consectetuer, tellus neque pretium ni</strong> </p>
        <p>Pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed Suspendisse elementum, justo at elementum consectetuer, </p>
      </div>
      <div class="tabbertab">
        <h2>Tab Option 2</h2>
        <p> Suspendisse elementum, <a href="#">justo at elementum</a> consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed </p>
        <blockquote class="clear">
          <p>Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed  Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed </p>
        </blockquote>
        <p>Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed  Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed </p>
        <p>Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed  Suspendisse elementum, justo at elementum consectetuer, tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. Cras condimentum feugiat sed </p>
      </div>
      <div class="tabbertab">
        <h2>Tab Option 3 </h2>
         <p class="tabtitle bold">Suspendisse elementum, justo at elementum consectetuer</p>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis  ligula. Phasellus tristique purus a augue condimentum adipiscing. Aenean  sagittis. Etiam leo pede.</p>
        
      </div>
    </div>
                  
          
</div><!--content #end-->
 <?php /*remix_code_end*/ ?>              

<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>
<!--include footer-->
<?php get_footer(); ?>