<?php
/*
Template Name: Home 04

Sidebar: false
*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
 <?php /*remix_code_start*/ ?>
     	<div id="content">
        
        	 <div id="banner2">
             	<h2>Lorem ipsum dolor site amet !</h2>              
              <div  class="content">
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus,  </p>
<p>fermentum id, molestie in,adipiscing. nonummy</p>
				<p class="aright"><a href="#">Read More &raquo; </a> </p>
               </div>
             </div><!--banner2 #end -->
             
             
             <div class="subcolumns alignleft">
             	<h2>Top 5 Most Popular Course</h2>
                <ul class="course">
                <li><a href="#">Maecenas urna purus, fermentum id </a></li>
                 <li><a href="#">molestie in, commodo  porttitor, felis. </a></li>
                 <li><a href="#">Nam blandit quam ut lacus. Quisque ornare </a></li>
                 <li><a href="#">risus quis  ligula. Phasellus tristique purus</a></li>
                  <li><a href="#">a augue condimentum adipiscing.</a></li>
                  <li><a href="#">Aenean  sagittis. Etiam leo pede, </a></li>
                <li><a href="#"> rhoncus venenatis, tristique in, vulputate at,  odio. </a></li>
                <li><a href="#"> Donec et ipsum et sapien vehicula nonummy. Suspendisse potenti.</a></li>
             	</ul>
             </div><!--subcolumns #end-->
             
             <div class="subcolumns alignright">
             	<h2>Certificate Series</h2>
                <ul class="course">
                <li><a href="#">Maecenas urna purus, fermentum id </a></li>
                 <li><a href="#">molestie in, commodo  porttitor, felis. </a></li>
                 <li><a href="#">Nam blandit quam ut lacus. Quisque ornare </a></li>
                 <li><a href="#">risus quis  ligula. Phasellus tristique purus</a></li>
                  <li><a href="#">a augue condimentum adipiscing.</a></li>
                  <li><a href="#">Aenean  sagittis. Etiam leo pede, </a></li>
                <li><a href="#"> rhoncus venenatis, tristique in, vulputate at,  odio. </a></li>
                <li><a href="#"> Donec et ipsum et sapien vehicula nonummy. Suspendisse potenti.</a></li>
             	</ul>
             </div><!--subcolumns #end-->
             
             
    </div><!--content #end-->
        
    <div id="sidebar">
   	  
        	<h2 class="t1">Why Wp Remix?</h2>
        	<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam ut lacus. </p>

        
        <hr class="hr" />
        
      <div class="news" >
       	  <p class="bold title"><a href="#">Lorem ipsum dolor sit amet </a></p>
        <img src="<?php bloginfo('template_url'); ?>/images/t5.png" alt="" class="imgleft"   />	<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam. <a href="#">more..</a> </p>
         </div><!--news end -->
         
         <div class="news" >
        	<p class="bold title"><a href="#">Lorem ipsum dolor sit amet </a></p>
        <img src="<?php bloginfo('template_url'); ?>/images/t5.png" alt="" class="imgleft"   />	<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam. <a href="#">more..</a> </p>
         </div><!--news end -->
         
        
         
          <img src="<?php bloginfo('template_url'); ?>/images/t6.png" alt="" class="imgright"   />
          <p>&ldquo; This is a statics testimonials Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam   &rdquo; </p>
	<p class="italic bold ">- Roger thomas </p>
         
        
        
</div><!--Sidebar #end-->
    
    <?php /*remix_code_end*/ ?>    
    
	
<!--include footer-->
<?php get_footer(); ?>