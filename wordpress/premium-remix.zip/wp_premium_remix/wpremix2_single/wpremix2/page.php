<?php while(have_posts()) : the_post(); ?>	
<?php
$rpostid = $post->ID;
$value = get_post_custom_values('_wp_remix_page_template', $rpostid);
if (isset($value[0])) {
	if ($value[0] != "none") {
		get_remix_header();
		$content = apply_filters('the_content', get_the_content());
		$content = preg_replace('/<\/div>$/', '', $content,1); //Fixes a WordPress div issue
		echo $content;
		//Sidebar
		
		$rsidebar = get_post_custom_values("_wp_remix_page_sidebar", $rpostid);
		if (isset($rsidebar[0])) {
			if (preg_match("/\|/i", $rsidebar[0])) {
				$rsidebar = split('\|',$rsidebar[0]);
				$rsidebar = trim($rsidebar[0]);
			} else {
				$rsidebar = trim($rsidebar[0]);
			}
			if (strtolower($rsidebar) == "default" || empty($rsidebar)) {
				get_sidebar();
			} elseif ($rsidebar != "false") {
				include (TEMPLATEPATH . '/includes/sidebar/' . $rsidebar . ".php");
			}
		} else {
			get_sidebar();
		}
		get_footer();
		break;	
		}
}
?>
<?php get_remix_header(); ?>
    
<div id="content-wrap" class="clear" >
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>

<div id="content">
      <h1 class="pagetitle"><?php the_title(); ?></h1>
      <!--post title-->
       <!--post with more link -->
      <div class="clear">
        <?php the_content('<p class="serif">continue</p>'); ?>
      </div>
      <!--if you paginate pages-->
      <?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
      <!--end of post and end of loop-->
 </div>
 
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>
<?php get_footer(); ?><!--include footer-->
<?php break; ?>
<?php endwhile; ?>