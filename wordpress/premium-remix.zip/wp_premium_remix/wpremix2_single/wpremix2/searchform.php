<div id="search clear">
 <form method="get" id="searchform" action="<?php bloginfo('home'); ?>">
<p><input type="text" value="Search here..." name="s"  onfocus="if (this.value == 'Search here...') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search here...';}" class="input"  />
<input type="submit" name="Submit"  class="button" value="Go"  /></p>
</form>
 

</div><!--Search End -->