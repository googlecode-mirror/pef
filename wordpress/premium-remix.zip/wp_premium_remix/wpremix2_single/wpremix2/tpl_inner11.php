<?php
/*
Template Name: Inner Page 11


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
 
<!--content #start -->
<div id="content">
   <h1 class="pagetitle"><?php the_title(); ?></h1>
	<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam.  </p>
    
    
     <ul class="helpline">
            <li class="i_csupport"><a href="#">Custmer Support</a><br />Quisque dapibus fermentum quam. Donec semper tempus enim. Quisque dapibus fermentum quam. Donec semper tempus enim.</li>
            <li class="i_job"><a href="#">Job</a><br />Quisque dapibus fermentum quam. Donec semper tempus enim. Quisque dapibus fermentum quam. Donec semper tempus enim.</li>
            <li class="i_comment"><a href="#">Comments</a><br />Quisque dapibus fermentum quam. Donec semper tempus enim. Quisque dapibus fermentum quam. Donec semper tempus enim.</li>
            <li class="i_affilate"><a href="#">Affilates &amp; Partners</a><br />Quisque dapibus fermentum quam. Donec semper tempus enim. Quisque dapibus fermentum quam. Donec semper tempus enim.</li>
              <li class="i_mike"><a href="#">Public Relations</a><br />Quisque dapibus fermentum quam. Donec semper tempus enim. Quisque dapibus fermentum quam. Donec semper tempus enim.</li>
                <li class="i_email"><a href="#">Contact Us</a><br />Quisque dapibus fermentum quam. Donec semper tempus enim. Quisque dapibus fermentum quam. Donec semper tempus enim.</li>
        </ul>
  
</div><!--content #end-->
  <?php /*remix_code_end*/ ?>
    
      
<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>
      
<!--include footer-->
<?php get_footer(); ?>