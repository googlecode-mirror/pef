<?php
/*
Template Name: Home 07

Sidebar: false
*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
 	
    <div id="l_sidebar">
    	<div class="welcometext"> 
        	<h2>Welcome to our Website.</h2>
            <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. </p>
<p>Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis  ligula. Phasellus tristique purus a augue condimentum adipiscing. Aenean  sagittis. </p>
         </div><!--welcome #end -->
         
         	<h3>Flickr Photos</h3>
            <div class="flickr">
          <?php /*remix_code_start*/ ?>
          <?php
global $options;
foreach ($options as $value) {
		global $$value['id'];
        if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
?>
         <script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=4&amp;display=latest&amp;size=s&amp;source=user&amp;user=<?php echo $wpr_flickr_id; ?>"></script>
         </div>
    </div><!-- l_sidebar #end -->
    
    
    <div id="mcontainer">
   		<h2>Latest Video</h2>
        <object width="400" height="265"><param name="movie" value="http://www.youtube.com/v/BMnZna107iE&hl=en" /></param><param name="wmode" value="transparent" /></param><embed src="http://www.youtube.com/v/BMnZna107iE&hl=en" type="application/x-shockwave-flash" wmode="transparent" width="400" height="265"></embed></object>
        
        <h3>Latest News</h3>
       
        <?php $page = (get_query_var('paged')) ? get_query_var('paged') : 1; query_posts("cat=$wpr_news&showposts=2&paged=$page"); while ( have_posts() ) : the_post()  ?>
       <div class="posts">
       	<div class="calendar"><?php the_time('j') ?> <span class="month"> <?php the_time('F') ?></span></div>
        
        <div class="pright">
         <p class="title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
		 <?php the_title(); ?></a> </p>
           <p class="author">Posted by <?php the_author_posts_link(); ?> at <?php the_time('g:i a') ?>  </p>
         
          <?php the_excerpt(); ?> 
         </div>
         
        </div><!--posts #end-->
 	  <?php endwhile; ?>
        
         
    </div><!-- mcontainer #end -->
    
    <div id="r_sidebar">
        
       
        
       	<h2>Services</h2>
 <ul class="services">
        <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. </li>
		<li>Praesent aliquam,  justo convallis luctus rutrum, erat</li>
		<li>nulla fermentum diam, at </li>
		<li>nonummy quam  ante ac quam. </li>
		<li>Maecenas urna purus, fermentum id</li>
		<li>nulla fermentum diam, at </li>
		<li>nonummy quam  ante ac quam. </li>
		<li>Maecenas urna purus, fermentum id</li>
         </ul>
        
        
       <h5>Testimonials </h5>
     <!-- dyanamic testimonials-->  
	 <?php include (TEMPLATEPATH . "/includes/testimonials.php"); ?>
     <!--# end--> 
  <?php /*remix_code_end*/ ?>
       
</div>
<!-- r_sidebar #end -->
    
   
<!--include footer-->
<?php get_footer(); ?>