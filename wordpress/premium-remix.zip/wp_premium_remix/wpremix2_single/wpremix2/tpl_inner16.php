<?php
/*
Template Name: Inner Page 16


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
<!--content #start -->
<div id="content">

  <h1 class="pagetitle"><?php the_title(); ?></h1>
      
      
      <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus. Dolor site amet aecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. Nam blandit quam ut lacus. </p>
      
      <div class="box">
      	<img src="<?php bloginfo('template_url'); ?>/images/s3.png" alt="" class="imgl"  />
        	<h5>Lorem ipsum dolor sit amet consectetuer</h5>
        	 <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam, justo convallis luctus rutrum,  Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. erat nulla fermentum diam, at nonummy quam ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo porttitor, felis. </p>
      </div>
      
      
      <div class="stepslist">
    	  <div class="steps">
       	<h2>Step 1 - The Services</h2>
        
         <ul class="feature">
            <li>Suspendisse elementum, justo at elementum consectetuer</li>
            <li>Tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. </li>
            <li>Cras condimentum dictum est. dictum est. lorem ipsum dolors</li>
        </ul>
         <p class="aright"> <a href="#" class="more">More Info</a></p>
       </div><!--product #end-->
        
        
        <div class="steps">
        	<h2>Step 2 - The Advantage</h2>
          <ul class="feature">
            <li>Suspendisse elementum, justo at elementum consectetuer</li>
            <li>Tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. </li>
            <li>Cras condimentum dictum est. dictum est. lorem ipsum dolors</li>
        </ul>
         <p class="aright"> <a href="#" class="more">More Info</a></p>
        </div><!--product #end-->
        
        
        <div class="steps">
        	<h2>Step 3 - The Result</h2>
          
         <ul class="feature">
            <li>Suspendisse elementum, justo at elementum consectetuer</li>
            <li>Tellus neque pretium nisi, quis pulvinar turpis nisl vitae urna. </li>
            <li>Cras condimentum dictum est. dictum est. lorem ipsum dolors</li>
        </ul>
         <p class="aright"> <a href="#" class="more">More Info</a></p>
        </div><!--product #end-->
        
     </div><!--stepslist #end -->
   
 
   
</div><!--content #end-->
 <?php /*remix_code_end*/ ?>  

 
<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>
 
<!--include footer-->
<?php get_footer(); ?>
