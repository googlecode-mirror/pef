<?php
/*
Template Name: Inner Page 02


*/
?>
<?php get_remix_header(); ?>

<div id="content-wrap">
<?php /*remix_code_start*/ ?>
<?php include(TEMPLATEPATH."/includes/breadcrumb.php");?>
 
<!--content #start -->
      <div id="content">
      		   <h1 class="pagetitle"><?php the_title(); ?></h1>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam ut lacus.  Dolor site amet aecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam ut lacus. </p>
                
                  <div class="profile_section">
                 	<div class="profile alignleft">
                    	<img src="<?php bloginfo('template_url'); ?>/images/p6.png" alt=""  class="imgleft" />
                        	<p class="bold">Roger Thomas  <br /> <small>Manager </small></p>
							<p>Quisque dapibus fermentum quam. Donec semper tempus enim. </p>
                    </div><!--profile #end-->
                    
                    <div class="profile alignright">
                    	<img src="<?php bloginfo('template_url'); ?>/images/p6.png" alt=""  class="imgleft" />
                        	<p class="bold">Mona libiana  <br /> <small>Creative Director </small></p>
							<p>Quisque dapibus fermentum quam. Donec semper tempus enim. </p>
                    </div><!--profile #end-->
                 
                 </div><!--profile section #end-->
                 
                  <div class="profile_section">
                 	<div class="profile alignleft">
                    	<img src="<?php bloginfo('template_url'); ?>/images/p6.png" alt=""  class="imgleft" />
                        	<p class="bold">Roy Mili <br /> <small>Marketing Executive</small></p>
							<p>Quisque dapibus fermentum quam. Donec semper tempus enim. </p>
                    </div><!--profile #end-->
                    
                    <div class="profile alignright">
                    	<img src="<?php bloginfo('template_url'); ?>/images/p6.png" alt=""  class="imgleft" />
                        	<p class="bold">Rodik Thomas  <br /> <small>Chairman </small></p>
							<p>Quisque dapibus fermentum quam. Donec semper tempus enim. </p>
                    </div><!--profile #end-->
                 
                 </div><!--profile section #end-->
                 
                 
                  <div class="profile_section">
                 	<div class="profile alignleft">
                    	<img src="<?php bloginfo('template_url'); ?>/images/p6.png" alt=""  class="imgleft" />
                        	<p class="bold">Roger Thomas  <br /> <small>Manager </small></p>
							<p>Quisque dapibus fermentum quam. Donec semper tempus enim. </p>
                    </div><!--profile #end-->
                    
                    <div class="profile alignright">
                    	<img src="<?php bloginfo('template_url'); ?>/images/p6.png" alt=""  class="imgleft" />
                        	<p class="bold">Roger Thomas  <br /> <small>Manager </small></p>
							<p>Quisque dapibus fermentum quam. Donec semper tempus enim. </p>
                    </div><!--profile #end-->
                 
                 </div><!--profile section #end-->
               
          
		</div><!--content #end-->
<?php /*remix_code_end*/ ?>
      
      
<!--include sidebar. 
To change the sidebar template, simply change the number. For example  "tpl_sidebar2.php" . The theme have 6 sidebars in total -->    
<?php include (TEMPLATEPATH . '/includes/sidebar/tpl_sidebar1.php'); ?>

<!--include footer-->
<?php get_footer(); ?>