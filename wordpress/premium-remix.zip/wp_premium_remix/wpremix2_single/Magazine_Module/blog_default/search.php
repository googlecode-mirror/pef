<?php include (TEMPLATEPATH . '/includes/header/header.php'); ?>  
    
<div id="content-wrap" class="clear" >
<div id="blog_content">
 
 
  <!--the loop-->
  <?php if (have_posts()) : ?>
  <h1>Search Results</h1>
    <!--loop article begin-->
  <?php while (have_posts()) : the_post(); ?>
  <!--post title as a link-->
 
 <div  class="posts">
		 <div class="post_top"> 
        	 <div class="calendar"><?php the_time('j') ?> <br /><span class="month"><?php the_time('F') ?></span></div>
        	 <div class="pright"><h2 class="h1" id="post-<?php the_ID(); ?>"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"> <?php the_title(); ?> </a></h2>
         <p>Posted by <span class="i_author"><?php the_author_posts_link(); ?></span>  <span class="i_comment2"><?php comments_popup_link('(0) Comment', '(1) Comment', '(%) Comment'); ?></span> </p> 
         </div><!-- pright #end -->
      
    </div><!--post_top #end -->
    
   
      
        <div class="clear">
                  <?php the_excerpt(); ?>
      </div>
    
    </div><!--post #end --> 
  <?php endwhile; ?>

  <!-- Previous/Next page navigation -->
    <?php if(function_exists('wp_pagenavi')) { ?>
  <div class="wp-pagenavi">
  	<?php wp_pagenavi();  ?>
  </div> 
 <?php } 
 
 else {?> 
    
  <div class="page-nav">
    <div class="nav-previous">
      <?php previous_posts_link('Previous Page') ?>
    </div>
    <div class="nav-next">
      <?php next_posts_link('Next Page') ?>
    </div>
  </div>
    
 <? } ?>
   
   
  <!-- do not delete-->
  <?php else : ?>
 		
		<?php include(TEMPLATEPATH."/includes/noposts.php");?> 
     
   <!--do not delete-->
  <?php endif; ?>
  <!--search.php end-->
</div>
         
<?php include(TEMPLATEPATH."/sidebar.php");?><!--include sidebar-->
<?php get_footer(); ?><!--include footer-->
