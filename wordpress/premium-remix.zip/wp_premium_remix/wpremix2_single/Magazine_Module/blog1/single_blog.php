<?php include (TEMPLATEPATH . '/includes/header/header.php'); ?>

<div id="content-wrap" class="clear sidebg" >
 
<div id="blog_content">
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  <!--post title-->
  
  <div class="posts">
  		    <div class="post_top"> 
    
    	 <div class="calendar"><?php the_time('j') ?> <br /><span class="month"><?php the_time('F') ?></span></div>
    
    	 <div class="pright"><h2 class="h1" id="post-<?php the_ID(); ?>"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"> <?php the_title(); ?> </a></h2>
         <p>Posted by <span class="i_author"><?php the_author_posts_link(); ?></span>   </p> 
         </div><!-- pright #end -->
      
    </div><!--post_top #end -->
    
        
         <div class="clear">  
    <?php the_content('continue'); ?>
	<div class="post_paginate"><?php wp_link_pages(__('Pages:')); ?> </div>                    
    </div>
           
      <!--Rateing-->
    <?php if(function_exists('the_ratings')) { the_ratings(); } ?>
    <!--Rateing end-->
    
    <div class="post_bottom"> <span class="cate"> Category : <?php the_category(' / ') ?></span>      
    
   					 <ul class="bookmark">
                    	<li>Bookmark :</li>
                        <li class="i_digg">
                        <a href="http://www.digg.com/post?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">Digg</a></li>
                        <li class="i_del">
                        <a href="http://del.icio.us/post?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">del.icip.us</a></li>
                        <li class="i_stumbel">
                        <a href="http://www.stumbleupon.com/submit?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">
                        Stumbleupon</a></li>
                        <li class="i_redit">
                        <a href="http://reddit.com/submit?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">Redit it</a></li>
                	</ul> 
    </div><!--post bottom #end-->
         
     
    </div><!--b1 content #end-->
   
    
    <?php comments_template(); ?>
    
    <!--do not delete-->
    <?php endwhile; else: ?>
    
    			<?php include(TEMPLATEPATH."/includes/noposts.php");?> 
    	
    <!--do not delete-->
    <?php endif; ?>
    <!--single.php end-->
  
</div>


<?php include(TEMPLATEPATH."/sidebar.php");?><!--include sidebar-->
<?php get_footer(); ?><!--include footer-->