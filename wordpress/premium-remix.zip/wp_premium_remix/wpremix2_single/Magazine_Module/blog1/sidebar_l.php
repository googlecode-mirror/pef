<div id="blog_sidebar_l" class="alignleft">
   <ul>
    <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(1) ) : else : ?>
    <li>
      <h5 class="sidebartitle">
        <?php _e('Category'); ?>
      </h5>
      <ul>
        <?php wp_list_categories('orderby=name&title_li'); ?>
      </ul>
    </li>
     <li>
      <h5 class="sidebartitle">
        <?php _e('Archives'); ?>
      </h5>
      <ul>
        <?php wp_get_archives('type=monthly'); ?>
      </ul>
    </li>
    <li>
      <h5 class="sidebartitle">
        <?php _e('Sponsors Links'); ?>
      </h5>
      <ul class="list-blogroll">
        <?php get_links('-1', '<li>', '</li>', '<br />', FALSE, 'id', FALSE, FALSE, -1, FALSE); ?>
      </ul>
    </li>
    <?php endif; ?>
  </ul>
 </div>
 