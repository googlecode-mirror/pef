<div id="blog_sidebar">
	<div class="sidebar_top">
    	<div class="sidebar_bottom">

<div class="advt">
	<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/ads_125x125.png"  alt=""  class="alignleft"   /></a>
    
    <div class="advt_r">
    	<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/ads_180x50.png"  alt=""    /></a>
        <a href="#"><img src="<?php bloginfo('template_url'); ?>/images/ads_180x50.png"  alt=""  class="advtspcer"   /></a> </div>
	</div>

  <?php include (TEMPLATEPATH . "/sidebar_l.php"); ?>
  <?php include (TEMPLATEPATH . "/sidebar_r.php"); ?>
  
  	</div>
  </div>
</div><!--sidebar #end -->