<?php include (TEMPLATEPATH . '/includes/header/header.php'); ?>

<div id="content-wrap" class="clear sidebg" >
<div id="blog_content">
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  <!--post title-->
  
  <div class="posts">
  
    <div class="post_top">
      <h2 class="h1" id="post-<?php the_ID(); ?>"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
        <?php the_title(); ?>
        </a></h2>
      <p> Posted by <span class="i_author">
        <?php the_author_posts_link(); ?>
        </span> at
        <?php the_time('jS F, Y') ?>
      </p>
    </div>
    <!--post_top #end -->
    
    
            <div class="clear">
              <?php the_content('continue'); ?>
			  <div class="post_paginate"><?php wp_link_pages(__('Pages:')); ?> </div>                    
            </div>
    
            <!--Rateing-->
            <?php if(function_exists('the_ratings')) { the_ratings(); } ?>
            <!--Rateing end-->
    
            <div class="post_bottom"> <span class="cate"> Category :
              <?php the_category(' / ') ?>
              </span> <span class="comment2">
              <?php comments_popup_link('(0) Comment', '(1) Comment', '(%) Comment'); ?>
              </span> </div>
            <!--post bottom #end-->
  </div> <!--post  #end-->
  <?php comments_template(); ?>
  <!--do not delete-->
  <?php endwhile; else: ?>
 
 		 <?php include(TEMPLATEPATH."/includes/noposts.php");?>
 
  <!--do not delete-->
  <?php endif; ?>
  <!--single.php end-->
</div>

<?php include(TEMPLATEPATH."/sidebar.php");?><!--include sidebar-->
<?php get_footer(); ?><!--include footer-->
