<?php
/*
Template Name: Blog
Exclude: true
*/
?>
<?php include (TEMPLATEPATH . '/includes/header/header.php'); ?>

<div id="content-wrap" class="clear" >

<div id="blog_content">
  <div class="content_top">
  
    <div class="featured posts_size2 alignleft blackbg">
      <p class="section_title">Featured Post</p>
      
      <?php $page = (get_query_var('paged')) ? get_query_var('paged') : 1; query_posts("cat=$wpr_featured&showposts=1&paged=$page"); while ( have_posts() ) : the_post()  ?>
      <?php $newsimg = get_post_meta($post->ID, 'newsimg', $single = true);	?>
      <div class="post"  id="post-<?php the_ID(); ?>">
      
        <?php if($newsimg !== '') { ?>
        <img src="<?php bloginfo('template_directory'); ?>/includes/phpthumb/phpThumb.php?src=<?php echo $newsimg; ?>&amp;w=260&amp;h=120&amp;zc=1" 
alt="<?php the_title(); ?>" class="postsimg"  />
        <?php }
		
    else { echo 'no thumb image available'; } ?>
    
        <div class="post_top">
          <h2 id="post-<?php the_ID(); ?>"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
            <?php the_title(); ?>
            </a></h2>
            
          <p> Posted by <span class="i_author">
            <?php the_author_posts_link(); ?>
            </span> at
            <?php the_time('jS F, Y') ?>
          </p>
          
        </div>
        <!--post_top #end -->
        
        <div class="clear">
          <?php the_excerpt(); ?>
        </div>
      </div>
      
      <!--post #end -->
      <?php endwhile; ?>
    </div>
    
    
    <!--videos -->
    <div class="featured posts_size2 alignright">
      <p class="section_title">Featured Video</p>
      <div class="video_object">
        <object width="260" height="200">
          <param name="movie" value="http://www.youtube.com/v/HaO89FrNa88&hl=en">
          </param>
          <param name="wmode" value="transparent">
          </param>
          <embed src="http://www.youtube.com/v/HaO89FrNa88&hl=en" type="application/x-shockwave-flash" wmode="transparent" width="260" height="200"></embed>
        </object>
        <ul>
          <li><a href="#">Video Title here</a></li>
        </ul>
      </div>
    </div>
    <!--videos -->
    
  </div>
  <!--content top #end -->
  
  
  
  <div class="postlist">
    <div class="blog_main" >
      <p class="section_title">Latest Posts</p>
      <?php {
  $page =(get_query_var('paged')) ? get_query_var ('paged') :".$wpr_index_posts";
 query_posts("cat=$wpr_exclude_news&paged=$page");
  } ?>
      <?php?>
      <?php if (have_posts()) : ?>
      <?php while (have_posts()) : the_post(); ?>
      <div  class="posts">
        <div class="post_top">
          <h2 id="post-<?php the_ID(); ?>"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
            <?php the_title(); ?>
            </a></h2>
          <p> Posted by <span class="i_author">
            <?php the_author_posts_link(); ?>
            </span> at
            <?php the_time('jS F, Y') ?>
          </p>
        </div>
        <!--post_top #end -->
        <div class="clear">
          <?php the_content('continue'); ?>
        </div>
        <!--Rateing-->
        <?php if(function_exists('the_ratings')) { the_ratings(); } ?>
        <!--Rateing end-->
        <div class="post_bottom"> <span class="cate"> Category :
          <?php the_category(' / ') ?>
          </span> <span class="comment2">
          <?php comments_popup_link('(0) Comment', '(1) Comment', '(%) Comment'); ?>
          </span> </div>
        <!--post bottom #end-->
      </div>
      <!--blog_content #end -->
      <?php endwhile; ?>
      <!--post #end -->
    </div>
    <!--blog_main #end-->
  </div>
  <!--post list #end -->
  <!-- Prev/Next page navigation -->
  <?php if(function_exists('wp_pagenavi')) { ?>
  <div class="wp-pagenavi">
    <?php wp_pagenavi();  ?>
  </div>
  <?php } 
 
 else {?>
  <div class="page-nav">
    <div class="nav-previous">
      <?php previous_posts_link('Previous Page') ?>
    </div>
    <div class="nav-next">
      <?php next_posts_link('Next Page') ?>
    </div>
  </div>
  <? } ?>
  <?php else : ?>
  <?php endif; ?>
</div>
<?php include(TEMPLATEPATH."/sidebar.php");?>
<!--include sidebar-->
<?php get_footer(); ?>
<!--include footer-->
