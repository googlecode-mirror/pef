<div id="blog_sidebar_r">
   <ul>
    <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(1) ) : else : ?>
     <li>
      <h5 class="sidebartitle">
        <?php _e('Sponsors Links'); ?>
      </h5>
      <ul class="list-blogroll">
        <?php get_links('-1', '<li>', '</li>', '<br />', FALSE, 'id', FALSE, FALSE, -1, FALSE); ?>
      </ul>
    </li>
    <?php endif; ?>
  </ul>
 </div>
 