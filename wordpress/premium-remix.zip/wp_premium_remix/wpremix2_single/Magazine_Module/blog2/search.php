<?php include (TEMPLATEPATH . '/includes/header/header.php'); ?>   
    
<div id="content-wrap" class="clear" >
<div id="blog_content">
  <!--the loop-->
  <?php if (have_posts()) : ?>
   <!--loop article begin-->
   
    <h1>Search Results</h1>

   
  <?php while (have_posts()) : the_post(); ?>
  <!--post title as a link-->
 
 
 <div  class="posts">
		   
           <div class="post_left">
         	<span class="date"><?php the_time('j F, Y') ?></span>
            <span class="author">by <strong><?php the_author_posts_link(); ?></strong></span>
            <span class="cate"><strong>Categories :</strong><br /> <?php the_category(' <br />') ?></span>
            <span class="comment"><?php comments_popup_link('(0) Comment', '(1) Comment', '(%) Comment'); ?></span>
         </div>
  		<!--post left #end -->        
      
      <div class="post_right">
    		
            <h2 class="h1" id="post-<?php the_ID(); ?>"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"> <?php the_title(); ?> </a></h2>
          
           <?php the_excerpt(); ?>
		   <div class="post_paginate"><?php wp_link_pages(__('Pages:')); ?> </div>                    
           
     </div><!-- pright #end -->
         
     </div><!--post #end --> 
  <?php endwhile; ?>

  <!-- Previous/Next page navigation -->
    <?php if(function_exists('wp_pagenavi')) { ?>
  <div class="wp-pagenavi">
  	<?php wp_pagenavi();  ?>
  </div> 
 <?php } 
 
 else {?> 
    
  <div class="page-nav">
    <div class="nav-previous">
      <?php previous_posts_link('Previous Page') ?>
    </div>
    <div class="nav-next">
      <?php next_posts_link('Next Page') ?>
    </div>
  </div>
    
 <? } ?>
   
   
  <!-- do not delete-->
  <?php else : ?>
      
 		<?php include(TEMPLATEPATH."/includes/noposts.php");?>    
   
   <!--do not delete-->
  <?php endif; ?>
  <!--search.php end-->
</div>
         
<?php include(TEMPLATEPATH."/sidebar.php");?><!-- include sidebar-->
<?php get_footer(); ?><!-- include footer-->
