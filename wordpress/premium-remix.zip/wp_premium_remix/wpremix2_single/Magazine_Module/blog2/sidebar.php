<div id="blog_sidebar">
  <?php include (TEMPLATEPATH . "/sidebar_l.php"); ?>
  <?php include (TEMPLATEPATH . "/sidebar_r.php"); ?>
</div>