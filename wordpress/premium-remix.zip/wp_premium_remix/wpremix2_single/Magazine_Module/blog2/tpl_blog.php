<?php
/*
Template Name: Blog
Exclude: true
*/
?>

<?php include (TEMPLATEPATH . '/includes/header/header.php'); ?>

<div id="content-wrap" class="clear" >

<div id="blog_banner">
	<div class="bcontent">
    	<h2>Welcome to my Blog</h2>
        <blockquote>
        	<p class="quote">Place powerful introductory lines about this site or you can write testimonials here. This is a great way to introduce your product or this site. dolor sit amet, consectetuer aliquam, justo convallis luctus rutrum,  adipiscing elit. Praesent aliquam, justo convallis luctus rutrum, erat nulla diam.</p>
        </blockquote>
    </div><!--bcontent #end-->
    
    <div class="ebook">
    	<h3>Featured Product Here</h3>
   	  <img src="<?php bloginfo('template_url'); ?>/images/ebook.png" alt=""  class="alginleft " />
   	  <p><strong>"Feature your product such as a book, digital product or membership program"</strong></p>
      <p>some more detail about the product should go here that will appeal the people to know more about the product. Lorem Ipsum.</p>
      <p><a href="#" class="bold alignright">Read More &raquo;</a></p>
    </div>
    
</div><!--banner #end-->

<div id="blog_content">
 
<!-- This page currently show 7 posts (showposts=7) per page.  Change it to number of posts you want to display.-->
<?php $page = (get_query_var('paged')) ? get_query_var('paged') : 1; query_posts("showposts=7&paged=$page"); while ( have_posts() ) : the_post(); $loopcounter++; ?>

			<div  class="posts">
                    <div class="post_left">
                    <span class="date"><?php the_time('j F, Y') ?></span>
                    <span class="author">by <strong><?php the_author_posts_link(); ?></strong></span>
                    <span class="cate"><strong>Categories :</strong><br /> <?php the_category(' <br />') ?></span>
                    <span class="comment"><?php comments_popup_link('(0) Comment', '(1) Comment', '(%) Comment'); ?></span>
                     </div> <!--post left #end -->


                    <div class="post_right">
                    
                        <h2 class="h1" id="post-<?php the_ID(); ?>">
                        <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
                        <?php the_title(); ?> </a></h2>
                        
                        <?php the_content('continue'); ?>
						<div class="post_paginate"><?php wp_link_pages(__('Pages:')); ?> </div>                    

                        <!--Rateing-->
                        <?php if(function_exists('the_ratings')) { the_ratings(); } ?>
                        <!--Rateing end-->
                                            
                        <ul class="bookmark">
                        	<li>Bookmark :</li>
                            <li class="i_digg">
                            <a href="http://www.digg.com/post?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">Digg</a></li>
                            <li class="i_del">
                            <a href="http://del.icio.us/post?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">del.icip.us</a></li>
                            <li class="i_stumbel">
                            <a href="http://www.stumbleupon.com/submit?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">
                            Stumbleupon</a></li>
                            <li class="i_redit">
                            <a href="http://reddit.com/submit?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">Redit it</a></li>
                        </ul> 
                    
                    </div><!-- pright #end -->
             
            </div><!--post #end-->
            
			<?php if ($loopcounter <= 1) { include (TEMPLATEPATH . '/includes/ad/blog_firstpost_ad.php'); } ?>

<?php endwhile; ?>
		

  <!-- Prev/Next page navigation -->
  <?php if(function_exists('wp_pagenavi')) { ?>
            <?php wp_pagenavi();  ?>
  <?php } 
 
 else {?>
                <div class="page-nav">
                <div class="nav-previous">
                <?php previous_posts_link('Previous Page') ?>
                </div>
                <div class="nav-next">
                <?php next_posts_link('Next Page') ?>
                </div>
                </div>
  <? } ?>

</div><!--blog_content #end -->

<?php include(TEMPLATEPATH."/sidebar.php");?><!--include sidebar-->
<?php get_footer(); ?><!--include footer-->