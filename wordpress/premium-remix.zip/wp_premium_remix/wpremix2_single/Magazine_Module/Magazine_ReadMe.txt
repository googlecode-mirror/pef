
HOW TO USE MAGAZINE MODULES?

A WP Remix module is a set of additional templates/functionalities that can be placed in the WP Remix theme and you can start using it by following simple instructions. 

Magazine module contains five different variation that you can use for your blog. By default, WP Remix offers a blog template as well. In the Magazine Module folder, you will find the following folder.

blog1
blog2
blog3
blog4
blog5
blog_default

Not all of them can work together. Instead, you can use any one of the 5 variation to set as your blog. To know how each of them looks, take a look at the "Template Guide" in the WP Remix theme package.

Once you have a choice, (For example, you like the blog1 template look.) simply open the folder. 

Copy all the contents in it. and overwrite them in the WP Remix theme folder. 

That's it. Go to your blog page and it will work fine.

