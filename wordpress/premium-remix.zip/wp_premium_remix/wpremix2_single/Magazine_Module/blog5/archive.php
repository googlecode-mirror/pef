<?php include (TEMPLATEPATH . '/includes/header/header.php'); ?>

<div id="content-wrap" class="clear" >
<div id="blog_content">
  <!--the loop-->
  <?php if (have_posts()) : ?>
  <h1>
    <?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
    <?php /* If this is a category archive */ if (is_category()) { ?>
    <?php echo single_cat_title(); ?>
    <?php /* If this is a daily archive */ } elseif (is_day()) { ?>
    Archive for
    <?php the_time('F jS, Y'); ?>
    <?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
    Archive for
    <?php the_time('F, Y'); ?>
    <?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
    Archive for
    <?php the_time('Y'); ?>
    <?php /* If this is a search */ } elseif (is_search()) { ?>
    Search Results
    <?php /* If this is an author archive */ } elseif (is_author()) { ?>
    Author Archive
    <?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
      Blog Archives
      <!--do not delete-->
      <?php } ?>
  </h1>
  <!--loop article begin-->
  <?php while (have_posts()) : the_post(); ?>
  <!--post title as a link-->
  
  <div class="posts">
    
     <div class="post_top">
                    <div class="post_top_left">
                    <h2 class="h1" id="post-<?php the_ID(); ?>">
                    <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
                    <?php the_title(); ?></a></h2>
                    <span class="auth">Posted on  By <strong> <?php the_author_posts_link(); ?></strong> at <?php the_time('j F, Y') ?>,
                    <?php the_time('g:i a') ?></span> </div>
                    
                    <div class="pcomments">
                    <?php comments_popup_link('0', '1', '%'); ?>
                    </div>
                    
                    </div><!--posttop #end -->
        
       
                      <div class="clear">
                      <?php the_content('continue'); ?>
                      </div>
      
                      <!--Rateing-->
                     <?php if(function_exists('the_ratings')) { the_ratings(); } ?>
                       <!--Rateing end-->
      
     <div class="post_bottom"> <span class="cate"> Category : <?php the_category(' | ') ?></span>  
                    
                      <ul class="bookmark">
                      		<li>Bookmark :</li>
                            <li class="i_digg">
                            <a href="http://www.digg.com/post?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">Digg</a></li>
                            <li class="i_del">
                            <a href="http://del.icio.us/post?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">del.icip.us</a></li>
                            <li class="i_stumbel">
                            <a href="http://www.stumbleupon.com/submit?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">
                            Stumbleupon</a></li>
                            <li class="i_redit">
                            <a href="http://reddit.com/submit?url=<?php echo get_permalink() ?>&amp;title=<?php the_title(); ?>">Redit it</a></li>
                         </ul> 
                       
                    </div><!--post bottom #end-->
    
    </div><!--post #end -->
      
 
  <!--one post end-->
  <?php endwhile; ?>
  <!-- Previous/Next page navigation -->
   
    <?php if(function_exists('wp_pagenavi')) { ?>
  <div class="wp-pagenavi">
  	<?php wp_pagenavi();  ?>
  </div> 
 <?php } 
 
 else {?> 
    
  <div class="page-nav">
    <div class="nav-previous">
      <?php previous_posts_link('Previous Page') ?>
    </div>
    <div class="nav-next">
      <?php next_posts_link('Next Page') ?>
    </div>
  </div>
    
 <? } ?>
   
   
  <!-- do not delete-->
  <?php else : ?>

   <?php include(TEMPLATEPATH."/includes/noposts.php");?>

  <!--do not delete-->
  <?php endif; ?>
  <!--archive.php end-->
</div>

<?php include(TEMPLATEPATH."/sidebar.php");?><!--include sidebar-->
<?php get_footer(); ?><!--include footer-->