
<?php
global $options;
foreach ($options as $value) {
		global $$value['id'];
        if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
?>
<div id="blog_sidebar" class="clearfix">
  <div class="subscribe">
    <a href="<?php bloginfo('rss2_url'); ?>"><img src="<?php bloginfo('template_url'); ?>/images/rss2.png" alt=""  class="rss" /></a>
    <div class="subscribetextbg">
    
    <div class="rssform">
     <p ><strong >SUBSCRIBE VIA EMAIL</strong></p>
      <form action="http://www.feedburner.com/fb/a/emailverify" method="post" target="popupwindow" onsubmit="window.open('http://www.feedburner.com/fb/a/emailverifySubmit?feedId=<?php echo $wpr_feedburner_id; ?>', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true">
        <input name="email" type="text" value="Your Email Address" class="subscribe_textield" onfocus="if (this.value == 'Your Email Address') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Your Email Address';}" />
        
        <input type="hidden" value="http://feeds.feedburner.com/~e?ffid=<?php echo $wpr_feedburner_id; ?>" name="url"/>
        <input type="hidden" value="<?php bloginfo('name'); ?>" name="title"/>
        <input type="hidden" name="loc" value="en_US"/>
        <input type="image" src="<?php bloginfo('template_url'); ?>/images/b_go2.png"   value="Subscribe" class="subscribe_b" />
      </form>
      </div>
    </div>
    
  </div>
  
  
  <div class="advt_spacer" >
  <a href="#"  rel="nofollow"><img src="<?php bloginfo('template_url'); ?>/images/advt_125x125.png" alt="" border="0" /></a>
 <a href="#" rel="nofollow"><img src="<?php bloginfo('template_url'); ?>/images/advt_125x125.png" alt="" border="0"  /></a>
  </div>
  
  
  
  <h5 class="sidebartitle">
        <?php _e('Sponsors'); ?>
      </h5>
    <div class="sponsors" >
   <img src="<?php bloginfo('template_url'); ?>/images/m2.png" alt=""  />
  <img src="<?php bloginfo('template_url'); ?>/images/m3.png" alt=""  />
   <img src="<?php bloginfo('template_url'); ?>/images/m3.png" alt=""  />
  <img src="<?php bloginfo('template_url'); ?>/images/m4.png" alt=""  />
  <img src="<?php bloginfo('template_url'); ?>/images/m3.png" alt=""  />
  <img src="<?php bloginfo('template_url'); ?>/images/m4.png" alt=""  />
  </div>
      
      
      <ul>
 <li><h5 class="sidebartitle">
        <?php _e('Category'); ?>
      </h5>
    	<ul>
        <?php wp_list_categories('orderby=name&title_li'); ?>
      </ul>
    </li>
    </ul>
   
  
  <?php include (TEMPLATEPATH . "/sidebar_l.php"); ?>
  <?php include (TEMPLATEPATH . "/sidebar_r.php"); ?>
</div>
<!--sidebar.php end-->
