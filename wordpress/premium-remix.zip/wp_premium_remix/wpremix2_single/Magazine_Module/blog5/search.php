<?php include (TEMPLATEPATH . '/includes/header/header.php'); ?>
	 
<div id="content-wrap" class="clear" >
 <div id="blog_content">
  <!--the loop-->
  <?php if (have_posts()) : ?>
   <!--loop article begin-->
   <h1>Search Result</h1>
  <?php while (have_posts()) : the_post(); ?>
  <!--post title as a link-->
 
 <div  class="posts">
		 <div class="post_top">
                    <div class="post_top_left">
                    <h2 class="h1" id="post-<?php the_ID(); ?>">
                    <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
                    <?php the_title(); ?></a></h2>
                    <span class="auth">Posted on  By <strong> <?php the_author_posts_link(); ?></strong> at <?php the_time('j F, Y') ?>,
                    <?php the_time('g:i a') ?></span> </div>
                    
                    <div class="pcomments">
                    <?php comments_popup_link('0', '1', '%'); ?>
                    </div>
                    
                    </div><!--posttop #end -->
    
                    <div class="clear">
                  <?php the_excerpt(); ?>
                   </div>
       
     </div><!--post #end --> 
  <?php endwhile; ?>

  <!-- Previous/Next page navigation -->
    <?php if(function_exists('wp_pagenavi')) { ?>
  <div class="wp-pagenavi">
  	<?php wp_pagenavi();  ?>
  </div> 
 <?php } 
 
 else {?> 
    
  <div class="page-nav">
    <div class="nav-previous">
      <?php previous_posts_link('Previous Page') ?>
    </div>
    <div class="nav-next">
      <?php next_posts_link('Next Page') ?>
    </div>
  </div>
    
 <? } ?>
   
   
  <!-- do not delete-->
  <?php else : ?>
 
   	<?php include(TEMPLATEPATH."/includes/noposts.php");?>

   <!--do not delete-->
  <?php endif; ?>
  <!--search.php end-->
</div>
         
<?php include(TEMPLATEPATH."/sidebar.php");?><!--include sidebar-->
<?php get_footer(); ?><!--include footer-->