<div id="blog_sidebar_r">

<div class="advt">
	<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/ads_180x50.png"  alt=""  class="alignleft"   /></a>
    <a href="#"><img src="<?php bloginfo('template_url'); ?>/images/ads_180x50.png"  alt=""  class="alignleft"   /></a>
    <a href="#"><img src="<?php bloginfo('template_url'); ?>/images/ads_180x50.png"  alt=""  class="alignleft"   /></a>
</div>

   <ul>
    <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(1) ) : else : ?>
     <li><h5 class="sidebartitle">
        <?php _e('Recent Comments'); ?>
      </h5>
         	 <?php include (TEMPLATEPATH . '/includes/simple_recent_comments.php'); /* recent comments plugin by: www.g-loaded.eu */?>
            <?php if (function_exists('src_simple_recent_comments')) { src_simple_recent_comments(5, 60, '', ''); } ?>
     </li>
    <li>
      <h5 class="sidebartitle">
        <?php _e('Recent Posts'); ?>
      </h5>
      <ul>
        <?php $recent = new WP_Query("cat=$wpr_exclude_news&showposts=7"); while($recent->have_posts()) : $recent->the_post();?>
        <li><a href="<?php the_permalink(); ?>">
          <?php the_title(); ?>
          </a> </li>
        <?php endwhile; ?>
      </ul>
    </li>
    <?php endif; ?>
  </ul>
 </div>
 