<div id="blog_sidebar_l">
 <ul>
  <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(2) ) : else : ?>
      <?php /* Menu for subpages of current page (copied from K2 theme) */
    global $notfound;
    if (is_page() and ($notfound != '2')) {
        $current_page = $post->ID;
        while($current_page) {
            $page_query = $wpdb->get_row("SELECT ID, post_title, post_status, post_parent FROM $wpdb->posts WHERE ID = '$current_page'");
            $current_page = $page_query->post_parent;
        }
        $parent_id = $page_query->ID;
        $parent_title = $page_query->post_title;

        // if ($wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_parent = '$parent_id' AND post_status != 'attachment'")) {
        if ($wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_parent = '$parent_id' AND post_type != 'attachment'")) {
    ?>
     <?php } } ?>
     <li>
      <h5 class="sidebartitle">
        <?php _e('Category'); ?>
      </h5>
      <ul>
        <?php wp_list_categories('orderby=name&title_li'); ?>
      </ul>
    </li>
    <li>
      <h5 class="sidebartitle">
        <?php _e('Archives'); ?>
      </h5>
      <ul>
        <?php wp_get_archives('type=monthly'); ?>
      </ul>
    </li>
    <li>
      <h5 class="sidebartitle">
        <?php _e('Sponsors Links'); ?>
      </h5>
      <ul class="list-blogroll">
        <?php get_links('-1', '<li>', '</li>', '<br />', FALSE, 'id', FALSE, FALSE, -1, FALSE); ?>
      </ul>
    </li>
   <?php endif; ?>
  </ul>
   </div>
<!--/sidebar -->